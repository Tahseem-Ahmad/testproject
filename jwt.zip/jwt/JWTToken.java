package com.netcop.econtent.jwt;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by soumya on 25/1/17.
 */
public class JWTToken {

    private String idToken;

    public JWTToken(){

    }

    public JWTToken(String idToken) {
        this.idToken = idToken;
    }

    @JsonProperty("id_token")
    public String getIdToken() {
        return idToken;
    }

    public void setIdToken(String idToken) {
        this.idToken = idToken;
    }
}