package com.application.config;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.retry.RetryPolicy;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by govind on 17/6/16.
 */

@Configuration
public class AWSConfiguration {

   @Value("${cloud.aws.credentials.accessKey}")
   public String accessKey;
 
   @Value("${cloud.aws.credentials.secretKey}")
   public String secretKey;

   @Value("${cloud.aws.region.static}")
   public String region;


    @Bean
    public BasicAWSCredentials basicAWSCredentials() {
        return new BasicAWSCredentials(accessKey, secretKey);
    }

    @Bean
    public ClientConfiguration clientConfiguration(){
    	ClientConfiguration clientConfiguration=new ClientConfiguration();
    	clientConfiguration.setMaxConnections(1000);
    	clientConfiguration.setMaxErrorRetry(2);
    	return clientConfiguration;
    }
    @Bean
    public AmazonS3Client amazonS3Client(AWSCredentials awsCredentials ,ClientConfiguration clientConfiguration) {
        AmazonS3Client amazonS3Client = new AmazonS3Client(awsCredentials,clientConfiguration);
        amazonS3Client.setRegion(Region.getRegion(Regions.fromName(region)));
        return amazonS3Client;
    }
}
