package com.application;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.ProxyCachingConfiguration;
import org.springframework.cloud.aws.autoconfigure.cache.ElastiCacheAutoConfiguration;
import org.springframework.cloud.aws.autoconfigure.context.ContextStackAutoConfiguration;
import org.springframework.cloud.aws.autoconfigure.mail.MailSenderAutoConfiguration;
import org.springframework.cloud.aws.core.env.stack.StackResourceRegistry;
import org.springframework.cloud.aws.core.env.stack.config.StackResourceRegistryFactoryBean;
import org.springframework.context.ConfigurableApplicationContext;

import com.application.service.FileUploaderService;

@EnableAutoConfiguration(exclude = { ElastiCacheAutoConfiguration.class, MailSenderAutoConfiguration.class,
		StackResourceRegistryFactoryBean.class, ContextStackAutoConfiguration.class, StackResourceRegistry.class,
		ProxyCachingConfiguration.class})
@SpringBootApplication
public class FileUploaderApplication {

	public static void main(String[] args) throws IOException, InterruptedException {
		ConfigurableApplicationContext ctx = SpringApplication.run(FileUploaderApplication.class, args);
		File source = new File("D:/Videos_New/");
		//System.out.println("Enter cameraID");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter date in YYYY-MM-DD fromat");
		String date=br.readLine();
		//System.out.println("You have Entered " + cameraId);
		ExecutorService executors = Executors.newFixedThreadPool(1000);
		for (File videos : source.listFiles()) {
			// System.out.println(videos);
			if (videos.isDirectory() && videos.listFiles().length > 0  ) {
				// System.out.println(videos.getName());
				
				File[] dateWiseFolder = videos.listFiles();
				for (File dt : dateWiseFolder) {
					if (dt.getName().equalsIgnoreCase(date)) {
						//System.out.println(dt.getName());
						File[] files = dt.listFiles();
						{
							for (File f : files) {
								if (f.getName().endsWith(".avi") || f.getName().endsWith(".mp4")) {
									
									Callable<String> task = () -> {
										ctx.getBean(FileUploaderService.class).uploadFile(f);
										return "ok";
									};
									Thread.sleep(15);
									executors.submit(task);
									
									
								}
							}
						}
					}
				}
			}
        
		}
	executors.shutdown();	
	}
		
}
