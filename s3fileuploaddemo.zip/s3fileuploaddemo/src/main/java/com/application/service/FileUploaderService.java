package com.application.service.impl;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.PutObjectResult;


@Service
public class FileUploaderService {

	
	
	
	@Autowired
	S3Wrapper s3Wrapper;
	
	Logger log=Logger.getLogger(FileUploaderService.class);
	@Async
	public void uploadFile(File file){
		 InputStream targetStream=null;
		//System.out.println("Inside uploadFile");
		   try {
			   //Thread.sleep(10000);
			   //File initialFile = new File("C:/WORKING_VOLUME/xvidia/videos/brightnoida/2016-06-27/brightnoida.130601.avi") ;
		      targetStream = FileUtils.openInputStream(file);
		      byte[] bytes = IOUtils.toByteArray(targetStream);
		      String filePath=file.getAbsolutePath().split("Videos_New\\\\")[1].replaceAll("\\\\","/");
		      //System.out.println("2====="+filePath);
		      
		      
		      List<PutObjectResult> results=null;
		      if(file.getName().endsWith(".avi")){
		    	  MultipartFile multipartFile = new MockMultipartFile("file",filePath,"",bytes);
			      MultipartFile multipartFileArr[]=new MultipartFile[1];
			      multipartFileArr[0]=multipartFile;
		    	  results= s3Wrapper.upload(multipartFileArr);  
		      }
		      else{
		    	  //StringBuilder newFilePath= new StringBuilder(filePath);
		    	  //newFilePath.setCharAt(filePath.length()-10, filePath.charAt(filePath.length()-5));
		    	  SimpleDateFormat sdf=new SimpleDateFormat("HHmmss");
		    	 
		    	  //Calendar calendar = Calendar.getInstance();
		    	 // calendar.setTimeInMillis(file.lastModified());
		    	  String timePrefix=sdf.format(new Date(file.lastModified()));
		    	  //int hour = calendar.get(Calendar.HOUR_OF_DAY);
		    	  //int minute = calendar.get(Calendar.MINUTE);
		    	  //int seconds = calendar.get(Calendar.SECOND);
		    	  String fileName = file.getName();
		    	  int i = fileName.lastIndexOf('.');
		    	  String extension = fileName.substring(i);
		    	  int j = fileName.indexOf('.');
		    	  String name = fileName.substring(0, j+1);
		    	  int k = filePath.lastIndexOf('/');
		    	  String prefix = filePath.substring(0,k+1);
		    	  String key=prefix+name+timePrefix+extension;
		    	  MultipartFile multipartFile = new MockMultipartFile("file",key,"",bytes);
				  log.error("KEY" +key);
			      MultipartFile multipartFileArr[]=new MultipartFile[1];
			      multipartFileArr[0]=multipartFile;
		    	  results= s3Wrapper.uploadMp4File(multipartFileArr); 
		    	  
              	 
		    	  
		      }
		      IOUtils.closeQuietly(targetStream);
		      results.forEach(i->{
		      FileUtils.deleteQuietly(file);
		      log.debug("From Upload-->" + i);
		      });
		      
		      
		   }
		   catch(Exception e){
			   e.printStackTrace();
		   }finally{
			   IOUtils.closeQuietly(targetStream);
		   }

	
	}
/*@Async
public void uploadMp4File(File file){
	System.out.println("Inside uploadMp4File");
	   try {
		   //Thread.sleep(10000);
		   //File initialFile = new File("C:/WORKING_VOLUME/xvidia/videos/brightnoida/2016-06-27/brightnoida.130601.avi") ;
	      InputStream targetStream = FileUtils.openInputStream(file);
	      byte[] bytes = IOUtils.toByteArray(targetStream);
	      String filePath=file.getAbsolutePath().split("videos\\\\")[1].replaceAll("\\\\","/");
	      //System.out.println("2====="+filePath);
	      MultipartFile multipartFile = new MockMultipartFile("file",filePath,"",bytes);
	      MultipartFile multipartFileArr[]=new MultipartFile[1];
	      multipartFileArr[0]=multipartFile;
	      List<PutObjectResult> results;
	     
	      IOUtils.closeQuietly(targetStream);
	      results.forEach(i->{
	      FileUtils.deleteQuietly(file);
	      log.info("From Upload-->" + i);
	      });
	   }
	   catch(Exception e){
		   e.printStackTrace();
	   }
}*/
}	

