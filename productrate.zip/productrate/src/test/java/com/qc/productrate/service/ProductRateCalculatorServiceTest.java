package com.qc.productrate.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mli.productrate.ProductRateApplication;
import com.mli.productrate.request.PlanCodes;
import com.mli.productrate.request.PremiumCalculatorAPIRequest;
import com.mli.productrate.request.PremiumCalculatorRequest;
import com.mli.productrate.request.RequestPayload;
import com.mli.productrate.request.RequestPlan;
import com.mli.productrate.request.RequestRider;
import com.mli.productrate.response.PremiumCalculatorApiResponse;
import com.mli.productrate.response.PremiumCalculatorResponse;
import com.mli.productrate.response.ResponsePayload;
import com.mli.productrate.response.ResponsePlan;
import com.mli.productrate.response.ResponseRider;
import com.mli.productrate.service.PremiumCalculator;
import com.mli.productrate.util.Header;
import com.mli.productrate.util.MessageConstants;
import com.mli.productrate.util.MessageInfo;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ProductRateApplication.class)
public class ProductRateCalculatorServiceTest {
	private String soaCorrelationId = "225163708";
	private String soaAppId = "NEO";
	private String planId = "TCOTP2";
	private String variantId= "SA";
	private String gender = "F";
	private String age= "28";
	private String empDiscount =  "N";
	private String planSumAssured =  "43000000";
	private String policyTerm = "29";
	private String policyPayTerm = "29";
	private String smoke = "Y";
	private String mode ="Monthly";
	private String riderId= "TCCIB";
	private String riderSA= "1000000";
	private String riderTerm= "32";


	private String responsePlanId = "TCOTP2";
	private String responseVariantId = "SA";
	private String responseGender = "F";
	private String responseAge = "28";
	private String responseEmpDiscount = "N";
	private String responsePlanSumAssured = "43000000";
	private String responsePolicyTerm = "29";
	private String responsePolicyPayTerm = "29";
	private String responseSmoke = "Y";
	private String responseMode = "Monthly";
	private String responseTotalPremiumWOGST = "2877.60";
	private String responseTotalPremiumWGST = "3396.0";
	private String responsePlanBasePremium ="2648.80";
	private String responsePlanWGST = "3126.0";
	private String responseTotalRiderPremiumWGST = "269.98";
	private String responseTotalRiderPremiumWOGST = "228.80";
	private String responsePlanGST="476.78";

	private String responseRiderId =  "TCCIB";
	private String responseRiderSA="1000000";
	private String responseRiderTerm ="32";
	private String responseRiderWGST = "270.0";
	private String responseRiderPremium = "228.80";
	private String responseRiderGST ="41.18";

	@Autowired
	PlanCodes planCodes;

	@Autowired
	PremiumCalculator premiumCalculator;
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		planCodes.initialize();
	}

	@Test
	public void testCalculatePremiumWithValidValues(){

		List<RequestRider> reqRider=new ArrayList<>();
		RequestRider requestRider=new RequestRider(riderId, riderSA, riderTerm);
		reqRider.add(requestRider);
		RequestPlan requestPlan=new RequestPlan(planId, variantId, gender, age, empDiscount, planSumAssured, policyTerm, policyPayTerm, smoke, mode);
		requestPlan.setReqRider(reqRider);
		Header header=new Header(soaAppId,soaCorrelationId);
		List<RequestPlan> reqPlan=new ArrayList<>();
		reqPlan.add(requestPlan);
		RequestPayload payload=new RequestPayload();
		payload.setReqPlan(reqPlan);
		PremiumCalculatorRequest request=new PremiumCalculatorRequest();
		request.setPayload(payload);
		request.setHeader(header);
		PremiumCalculatorAPIRequest apiRequest = new PremiumCalculatorAPIRequest();
		apiRequest.setRequest(request);

		PremiumCalculatorApiResponse actualResponse = premiumCalculator.calculatePremium(apiRequest);

		PremiumCalculatorApiResponse expectedResponse= new PremiumCalculatorApiResponse(); 
		
		PremiumCalculatorResponse response=new PremiumCalculatorResponse();
		response.setHeader(header);
		MessageInfo msgInfo =new MessageInfo(MessageConstants.C200,MessageConstants.SUCCESS,MessageConstants.C200DESC);
		response.setMsgInfo(msgInfo);
		
		ResponsePayload responsePayload=new ResponsePayload();
		List<ResponsePlan> resPlan=new ArrayList<>();
		ResponsePlan responsePlan=new ResponsePlan();
		responsePlan.setPlanId(responsePlanId);
		responsePlan.setAge(responseAge);
		responsePlan.setEmpDiscount(responseEmpDiscount);
		responsePlan.setGender(responseGender);
		responsePlan.setPlanGST(responsePlanGST);
		responsePlan.setMode(responseMode);
		responsePlan.setPlanBasePremium(responsePlanBasePremium);
		responsePlan.setPlanSumAssured(responsePlanSumAssured);
		responsePlan.setPlanWGST(responsePlanWGST);
		responsePlan.setPolicyTerm(responsePolicyTerm);
		responsePlan.setPolicyPayTerm(responsePolicyPayTerm);
		responsePlan.setVariantId(responseVariantId);
		responsePlan.setMode(responseMode);
		responsePlan.setTotalPremiumWGST(responseTotalPremiumWGST);
		responsePlan.setTotalPremiumWOGST(responseTotalPremiumWOGST);
		responsePlan.setTotalRiderPremiumWGST(responseTotalRiderPremiumWGST);
		responsePlan.setTotalRiderPremiumWOGST(responseTotalRiderPremiumWOGST);
		responsePlan.setSmoke(responseSmoke);
		resPlan.add(responsePlan);
		
		List<ResponseRider> resRider=new ArrayList<>();
		ResponseRider responseRider=new ResponseRider();
		responseRider.setRiderId(responseRiderId);
		responseRider.setRiderSA(responseRiderSA);
		responseRider.setRiderTerm(responseRiderTerm);
		responseRider.setRiderGST(responseRiderGST);
		responseRider.setRiderPremium(responseRiderPremium);
		responseRider.setRiderWGST(responseRiderWGST);
		resRider.add(responseRider);
		
		responsePlan.setResRider(resRider);
		
		responsePayload.setResPlan(resPlan);
		response.setPayload(responsePayload);
	    expectedResponse.setResponse(response);
	    
		assertEquals(expectedResponse.getResponse().getHeader(), actualResponse.getResponse().getHeader());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgCode(), actualResponse.getResponse().getMsgInfo().getMsgCode());
		assertEquals(expectedResponse.getResponse().getPayload().getResPlan().size(),actualResponse.getResponse().getPayload().getResPlan().size());
		assertEquals(expectedResponse.getResponse().getPayload().getResPlan().get(0).getPlanId(), actualResponse.getResponse().getPayload().getResPlan().get(0).getPlanId());
	}
	
	@Test
	public void testCalculatePremiumWithInvalidValues(){                                      
		List<RequestRider> reqRider=new ArrayList<>();
		RequestRider requestRider=new RequestRider(riderId, riderSA, riderTerm);
		reqRider.add(requestRider);

		RequestPlan requestPlan=new RequestPlan("TCOTP22", variantId, gender, age, empDiscount, planSumAssured, policyTerm, policyPayTerm, smoke, mode);
		requestPlan.setReqRider(reqRider);
		Header header=new Header(soaAppId,soaCorrelationId);
		List<RequestPlan> reqPlan=new ArrayList<>();
		reqPlan.add(requestPlan);
		RequestPayload payload=new RequestPayload();
		payload.setReqPlan(reqPlan);
		PremiumCalculatorRequest request=new PremiumCalculatorRequest();
		request.setPayload(payload);
		request.setHeader(header);
		PremiumCalculatorAPIRequest apiRequest = new PremiumCalculatorAPIRequest();
		apiRequest.setRequest(request);

		PremiumCalculatorApiResponse actualResponse = premiumCalculator.calculatePremium(apiRequest);

		PremiumCalculatorApiResponse expectedResponse= new PremiumCalculatorApiResponse(); 
		
		PremiumCalculatorResponse response=new PremiumCalculatorResponse();
		response.setHeader(header);
		MessageInfo msgInfo =new MessageInfo(MessageConstants.C700,MessageConstants.FAILURE,MessageConstants.C700DESC);
		response.setMsgInfo(msgInfo);
		ResponsePayload responsePayload=new ResponsePayload();
		response.setPayload(responsePayload);
	    expectedResponse.setResponse(response);
	    
		assertEquals(expectedResponse.getResponse().getHeader(), actualResponse.getResponse().getHeader());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgCode(), actualResponse.getResponse().getMsgInfo().getMsgCode());
		assertEquals(null,actualResponse.getResponse().getPayload());
	}
	
	@Test
	public void testCalculatePremiumWithoutMandatoryHeader(){                                      
		List<RequestRider> reqRider=new ArrayList<>();
		RequestRider requestRider=new RequestRider(riderId, riderSA, riderTerm);
		reqRider.add(requestRider);

		RequestPlan requestPlan=new RequestPlan(planId, variantId, gender, age, empDiscount, planSumAssured, policyTerm, policyPayTerm, smoke, mode);
		requestPlan.setReqRider(reqRider);
		Header header=new Header(null,null);
		List<RequestPlan> reqPlan=new ArrayList<>();
		reqPlan.add(requestPlan);
		RequestPayload payload=new RequestPayload();
		payload.setReqPlan(reqPlan);
		PremiumCalculatorRequest request=new PremiumCalculatorRequest();
		request.setPayload(payload);
		request.setHeader(header);
		PremiumCalculatorAPIRequest apiRequest = new PremiumCalculatorAPIRequest();
		apiRequest.setRequest(request);

		PremiumCalculatorApiResponse actualResponse = premiumCalculator.calculatePremium(apiRequest);

		PremiumCalculatorApiResponse expectedResponse= new PremiumCalculatorApiResponse(); 
		
		PremiumCalculatorResponse response=new PremiumCalculatorResponse();
		response.setHeader(header);
		MessageInfo msgInfo =new MessageInfo(MessageConstants.C600,MessageConstants.FAILURE,MessageConstants.C600HDESC);
		response.setMsgInfo(msgInfo);
		ResponsePayload responsePayload=new ResponsePayload();
		response.setPayload(responsePayload);
	    expectedResponse.setResponse(response);
	    
		assertEquals(null, actualResponse.getResponse().getHeader());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgCode(), actualResponse.getResponse().getMsgInfo().getMsgCode());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsg(), actualResponse.getResponse().getMsgInfo().getMsg());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgDescription(), actualResponse.getResponse().getMsgInfo().getMsgDescription());
		assertEquals(null,actualResponse.getResponse().getPayload());
	}	

	@Test
	public void testCalculatePremiumWithoutMandatoryPayload(){                                      
		
		RequestPlan requestPlan=new RequestPlan();
		Header header=new Header(soaAppId,soaCorrelationId);
		List<RequestPlan> reqPlan=new ArrayList<>();
		reqPlan.add(requestPlan);
		RequestPayload payload=new RequestPayload();
		payload.setReqPlan(reqPlan);
		PremiumCalculatorRequest request=new PremiumCalculatorRequest();
		request.setPayload(payload);
		request.setHeader(header);
		PremiumCalculatorAPIRequest apiRequest = new PremiumCalculatorAPIRequest();
		apiRequest.setRequest(request);
		
		PremiumCalculatorApiResponse actualResponse = premiumCalculator.calculatePremium(apiRequest);

		PremiumCalculatorApiResponse expectedResponse= new PremiumCalculatorApiResponse(); 
		
		PremiumCalculatorResponse response=new PremiumCalculatorResponse();
		response.setHeader(header);
		MessageInfo msgInfo =new MessageInfo(MessageConstants.C500,MessageConstants.FAILURE,MessageConstants.C500DESC);
		response.setMsgInfo(msgInfo);
		ResponsePayload responsePayload=new ResponsePayload();
		response.setPayload(responsePayload);
	    expectedResponse.setResponse(response);
	    
		assertEquals(expectedResponse.getResponse().getHeader(), actualResponse.getResponse().getHeader());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgCode(), actualResponse.getResponse().getMsgInfo().getMsgCode());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsg(), actualResponse.getResponse().getMsgInfo().getMsg());
		assertEquals(expectedResponse.getResponse().getMsgInfo().getMsgDescription(), actualResponse.getResponse().getMsgInfo().getMsgDescription());
		assertEquals(null,actualResponse.getResponse().getPayload());
	}	

}
