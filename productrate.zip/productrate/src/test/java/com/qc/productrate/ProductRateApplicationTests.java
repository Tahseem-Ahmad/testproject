package com.qc.productrate;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mli.productrate.ProductRateApplication;
import com.mli.productrate.dao.NeoDao;
import com.mli.productrate.response.PlanDetailBean;
import com.mli.productrate.service.impl.PlanDetailService;



@RunWith(SpringRunner.class)
@SpringBootTest(classes=ProductRateApplication.class)
public class ProductRateApplicationTests {

	private final static String PLAN_ID="DCCCP";
	private final static String RBTL_AGE_DUR="28";
	private final static String RBTL_SEX="F";
	private String planId1="DCCCP"; 
	private String rhID1="CCOPR"; 
	private String rtblId1="CCOPR1"; 
	private String rhBandAmount1="1000000"; 
	private String rtblSexCd1="F"; 
	private String discountOption1="JA"; 
	private String smokerCode1=""; 
    private String rtblMatXpryDur1="29"; 
    private String issueAge1="28"; 
	private String rtblAge1="028";
	private String rtbl1rt1="0"; 
	private String planId2="DCCCP"; 
	private String rhID2="CCOPR"; 
	private String rtblId2="CCOPR1"; 
	private String rhBandAmount2="1000000"; 
	private String rtblSexCd2="F";
	private String discountOption2="JA"; 
	private String smokerCode2="";
	private String rtblMatXpryDur2="20"; 
	private String issueAge2="28";
	private String rtblAge2="028"; 
	private String rtbl1rt2="0"; 
	

	
	@InjectMocks
	PlanDetailService planDetail;
	
	@Mock
	NeoDao neoDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);	
	}

	@Test
	public void contextLoads() {
		List<PlanDetailBean> planDetails = new ArrayList<>();
	    Mockito.when(neoDao.callPlanDetail("","","")).thenReturn(planDetails);
 
	    List<PlanDetailBean> actualPlanDetails = planDetail.callPlanDetailService("","","");
	    assertEquals(planDetails.size(), actualPlanDetails.size());
	    
	    
	}
	
	@Test
	public void testCallPlanDetailWithValidValues(){
	  List<PlanDetailBean> planDetails = new ArrayList<>();
	  planDetails.add(new PlanDetailBean(planId1, rhID1, rtblId1, rhBandAmount1, rtblSexCd1, discountOption1, smokerCode1, rtblMatXpryDur1, issueAge1, rtblAge1, rtbl1rt1));
	  planDetails.add(new PlanDetailBean(planId2, rhID2, rtblId2, rhBandAmount2, rtblSexCd2, discountOption2, smokerCode2, rtblMatXpryDur2, issueAge2, rtblAge2, rtbl1rt2));
	  Mockito.when(neoDao.callPlanDetail(PLAN_ID, RBTL_AGE_DUR, RBTL_SEX)).thenReturn(planDetails) ;
	  
	  List<PlanDetailBean> actualPlanDetails = planDetail.callPlanDetailService(PLAN_ID, RBTL_AGE_DUR, RBTL_SEX);
	  assertEquals(planDetails.size(), actualPlanDetails.size());
	  assertEquals(planDetails, actualPlanDetails);
	  assertEquals(planDetails.get(0), actualPlanDetails.get(0));
	}

	@Test
	public void testCallPlanDetailsWithInvalidValues(){
		  List<PlanDetailBean> planDetails = new ArrayList<>();
		  Mockito.when(neoDao.callPlanDetail("TP", RBTL_AGE_DUR, RBTL_SEX)).thenReturn(planDetails) ;
		  
		  List<PlanDetailBean> actualPlanDetails = planDetail.callPlanDetailService("TP",RBTL_AGE_DUR,RBTL_SEX);
		  assertEquals(planDetails.size(), actualPlanDetails.size());
		
	}
	

}
