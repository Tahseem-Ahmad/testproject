package com.qc.productrate.config.service;

public interface ProductRateService {

}
