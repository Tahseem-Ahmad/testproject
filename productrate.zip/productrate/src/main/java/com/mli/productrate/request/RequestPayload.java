package com.mli.productrate.request;
import java.io.Serializable;
import java.util.List;

import javax.validation.constraints.NotEmpty;

public class RequestPayload implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@NotEmpty(message="Request Paln is mandatory field")
	private List<RequestPlan> reqPlan;
	public List<RequestPlan> getReqPlan() {
		return reqPlan;
	}
	public void setReqPlan(List<RequestPlan> reqPlan) {
		this.reqPlan = reqPlan;
	}
	
	@Override
	public String toString() {
		return "RequestPayload [reqPlan=" + reqPlan + "]";
	}
	

}
