package com.mli.productrate.request;
import java.io.Serializable;
public class RequestRider implements Serializable{
	private static final long serialVersionUID = 1L;
	private String riderId ;
	private String riderSA; 
	private String riderTerm ;
	public RequestRider(){
		
	}
	public RequestRider(String riderId, String riderSA, String riderTerm) {
		super();
		this.riderId = riderId;
		this.riderSA = riderSA;
		this.riderTerm = riderTerm;
	}
	public String getRiderId() {
		return riderId;
	}
	public void setRiderId(String riderId) {
		this.riderId = riderId;
	}
	public String getRiderSA() {
		return riderSA;
	}
	public void setRiderSA(String riderSA) {
		this.riderSA = riderSA;
	}
	public String getRiderTerm() {
		return riderTerm;
	}
	public void setRiderTerm(String riderTerm) {
		this.riderTerm = riderTerm;
	}
	@Override
	public String toString() {
		return "RequestRider [riderId=" + riderId + ", riderSA=" + riderSA + ", riderTerm=" + riderTerm + "]";
	}
	
}

