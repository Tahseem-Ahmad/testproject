package com.mli.productrate.request;

import java.io.Serializable;
import java.util.List;

/**
 * @author ad01084
 *
 */
public class RequestPlan extends RequestPlanData implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public RequestPlan() {
		super();
	}
	public RequestPlan(String planId, String variantId, String gender, String age, String empDiscount,
			String planSumAssured, String policyTerm, String policyPayTerm, String smoke, String mode) {
		super(planId, variantId, gender, age, empDiscount, planSumAssured, policyTerm, policyPayTerm, smoke, mode);
		
	}
	private List<RequestRider> reqRider;
	
	public List<RequestRider> getReqRider() {
		return reqRider;
	}
	public void setReqRider(List<RequestRider> reqRider) {
		this.reqRider = reqRider;
	}
	@Override
	public String toString() {
		return "RequestPlan [reqRider=" + reqRider + "]";
	}
}
