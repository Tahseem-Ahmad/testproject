package com.mli.productrate.dao.impl;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;
import org.hibernate.procedure.ProcedureOutputs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mli.productrate.dao.NeoDao;
import com.mli.productrate.response.PlanDetailBean;

import oracle.jdbc.OracleTypes;

@Service
public class NeoDaoImpl implements NeoDao{

	Logger logger =LoggerFactory.getLogger(NeoDaoImpl.class);


	@Autowired
	@Qualifier("stagcdcManagerFactory")
	EntityManagerFactory entityManagerFactory;

	@Override
	public List<PlanDetailBean> callPlanDetail(String planid, String rtblAgeDur, String rtblSex ) {
		Session session =entityManagerFactory.createEntityManager().unwrap(Session.class);
		List<PlanDetailBean> planDetailBeans=session.doReturningWork(
				connection -> {
					List<PlanDetailBean> list=null;
					try (CallableStatement function = connection.prepareCall("{ ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) }")) {
						function.registerOutParameter( 1, OracleTypes.CURSOR);
						function.setString(2, planid);
						function.setString(3, rtblAgeDur);
						function.setString(4, rtblSex);
						function.execute();
					    ResultSet rs=(ResultSet) function.getObject(1);
					    if(rs!= null)
						{
					    	list=getPlanDetailListFromResultSet(rs);
						}
					   
					}catch (Exception e) {
						logger.error("Exception while calling function : { ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) }" + e);
					}
					return list;
				} );

		
	    logger.debug(" Function : { ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) } Result - >"+planDetailBeans);
		return planDetailBeans;
	}

	@Override
	public List<Object[]> callPlanDetailsV2(String plans, String rtblAgeDur, String rtblSex, String empDiscount) {
		StoredProcedureQuery query =entityManagerFactory.createEntityManager().createStoredProcedureQuery("PR_NEO_RATE_WEB_SERVICE_OTP")
				.registerStoredProcedureParameter(1, String.class, ParameterMode.IN)
				.registerStoredProcedureParameter(2, String.class, ParameterMode.IN)
				.registerStoredProcedureParameter(3, String.class, ParameterMode.IN)
				.registerStoredProcedureParameter(4, String.class, ParameterMode.IN)
				.registerStoredProcedureParameter(5, Class.class, ParameterMode.REF_CURSOR)
				.setParameter(1, plans)
				.setParameter(2, rtblAgeDur)
				.setParameter(3, rtblSex)
				.setParameter(4, empDiscount);
		try {
			query.execute();
			@SuppressWarnings("unchecked")
			List<Object[]> planDetails=  query.getResultList();
			logger.debug(" Procedure :PR_NEO_RATE_WEB_SERVICE_OTP Result - >"+planDetails);
			return planDetails;
		}catch (Exception e) {
			logger.error("Exception while calling proc : - PR_NEO_RATE_WEB_SERVICE_OTP"+ e);
		}finally {
			query.unwrap(ProcedureOutputs.class).release();
		}
		
		return new ArrayList<>();
	}



	private List<PlanDetailBean> getPlanDetailListFromResultSet(ResultSet resultSet){
		List<PlanDetailBean> pladDetailBeans=new ArrayList<>();
		try {
			while(resultSet.next()){
				PlanDetailBean planDetailBean = new PlanDetailBean();
				planDetailBean.setPlanId(resultSet.getString("PLAN_ID")!=null?resultSet.getString("PLAN_ID").trim():"");
				planDetailBean.setRhID(resultSet.getString("RH_ID")!=null?resultSet.getString("RH_ID").trim():"");
				planDetailBean.setRtblId(resultSet.getString("RTBL_ID")!=null?resultSet.getString("RTBL_ID").trim():"");
				planDetailBean.setRhBandAmount(resultSet.getString("RH_BAND_AMT")!=null?resultSet.getString("RH_BAND_AMT").trim():"");
				planDetailBean.setRtblSexCd(resultSet.getString("RTBL_SEX_CD")!=null?resultSet.getString("RTBL_SEX_CD").trim():"");
				planDetailBean.setDiscountOption(resultSet.getString("DISCOUNT_OPTION")!=null?resultSet.getString("DISCOUNT_OPTION").trim():"");
				planDetailBean.setSmokerCode(resultSet.getString("SMOKER_CODE")!=null?resultSet.getString("SMOKER_CODE").trim():"");
				planDetailBean.setRtblMatXpryDur(resultSet.getString("RTBL_MAT_XPRY_DUR")!=null?resultSet.getString("RTBL_MAT_XPRY_DUR").trim():"");
				planDetailBean.setIssueAge(resultSet.getString("ISSUE_AGE")!=null?resultSet.getString("ISSUE_AGE").trim():"");
				planDetailBean.setRtblAge(resultSet.getString("RTBL_AGE")!=null?resultSet.getString("RTBL_AGE").trim():"");
				planDetailBean.setRtbl1rt(resultSet.getString("RTBL_1_RT")!=null?resultSet.getString("RTBL_1_RT").trim():"");
				pladDetailBeans.add(planDetailBean);
			}
		} catch (SQLException e) {
		   logger.error("Exception while parsing ResultSet :"+ e);
		}
		return pladDetailBeans;	
	}	
}