package com.mli.productrate.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mli.productrate.request.PremiumCalculatorAPIRequest;
import com.mli.productrate.response.PremiumCalculatorApiResponse;
import com.mli.productrate.service.PremiumCalculator;

@RestController
@RequestMapping("/neo/api")
public class NeoController {

	@Autowired
	PremiumCalculator premiumCalculator;
	
	@PostMapping(value = "/v1/premiumcalculation",consumes = { "application/json" }, produces = {"application/json"})
	public PremiumCalculatorApiResponse calculatePremium(@Valid @RequestBody PremiumCalculatorAPIRequest apiRequest){
		return premiumCalculator.calculatePremium(apiRequest);
		
	}
	
}
