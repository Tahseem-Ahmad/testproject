package com.mli.productrate.request;

import java.io.Serializable;

public class PremiumCalculatorAPIRequest implements Serializable{

	private static final long serialVersionUID = 1L;
    private PremiumCalculatorRequest request;
	public PremiumCalculatorRequest getRequest() {
		return request;
	}
	public void setRequest(PremiumCalculatorRequest request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "PremiumCalculatorAPIRequest [request=" + request + "]";
	}
    
}
