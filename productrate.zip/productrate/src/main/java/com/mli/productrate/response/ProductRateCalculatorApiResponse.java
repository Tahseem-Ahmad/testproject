package com.mli.productrate.response;

import java.io.Serializable;

public class ProductRateCalculatorApiResponse implements Serializable{
	private static final long serialVersionUID = 1L;
	private ProductRateCalculatorResponse response;
	public ProductRateCalculatorApiResponse(){}
	public ProductRateCalculatorApiResponse(ProductRateCalculatorResponse response) {
		this.response = response;
	}
	public ProductRateCalculatorResponse getResponse() {
		return response;
	}
	public void setResponse(ProductRateCalculatorResponse response) {
		this.response = response;
	}
	
	@Override
	public String toString() {
		return "PremiumCalculatorApiResponse [response=" + response + "]";
	}
	

}
