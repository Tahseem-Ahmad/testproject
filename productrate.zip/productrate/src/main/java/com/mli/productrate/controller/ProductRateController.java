package com.mli.productrate.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.mli.productrate.request.ProductRateCalculatorApiRequest;
import com.mli.productrate.response.ProductRateCalculatorApiResponse;
import com.mli.productrate.service.ProductRateCalulator;

/**
 * 
 * @author Tahseem 
 *
 */
@Controller
@CrossOrigin(maxAge=3600,methods={RequestMethod.GET,RequestMethod.POST},origins="*")
public class ProductRateController {

	Logger log=LoggerFactory.getLogger(ProductRateController.class);
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@Autowired
	ProductRateCalulator productRateCalculator;
	
	@RequestMapping(value = "/v1/premiumcalculation",consumes = { "application/json" }, produces = {"application/json"})
	@ResponseBody
	public ProductRateCalculatorApiResponse calculateProductRate(@Valid @RequestBody ProductRateCalculatorApiRequest apiRequest){
		return productRateCalculator.calculateProductRate(apiRequest);
		
	}	
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach(error -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	}
}
