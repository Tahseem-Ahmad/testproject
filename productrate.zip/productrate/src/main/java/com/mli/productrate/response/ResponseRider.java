package com.mli.productrate.response;

import java.io.Serializable;

import com.mli.productrate.request.RequestRider;


public class ResponseRider extends RequestRider implements Serializable {

	private static final long serialVersionUID = 1L;
	private String riderWGST="";
	private String riderPremium="";
	private String riderGST = "";
	public String getRiderWGST() {
		return riderWGST;
	}
	public void setRiderWGST(String riderWGST) {
		this.riderWGST = riderWGST;
	}
	public String getRiderPremium() {
		return riderPremium;
	}
	public void setRiderPremium(String riderPremium) {
		this.riderPremium = riderPremium;
	}
	public String getRiderGST() {
		return riderGST;
	}
	public void setRiderGST(String riderGST) {
		this.riderGST = riderGST;
	}
	@Override
	public String toString() {
		return "ResponseRider [riderWGST=" + riderWGST + ", riderPremium=" + riderPremium + ", riderGST=" + riderGST
				+ "]";
	}
}
