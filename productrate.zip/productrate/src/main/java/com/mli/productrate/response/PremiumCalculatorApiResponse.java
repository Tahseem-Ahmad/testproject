package com.mli.productrate.response;

import java.io.Serializable;

public class PremiumCalculatorApiResponse implements Serializable{
	private static final long serialVersionUID = 1L;
	private PremiumCalculatorResponse response;
	public PremiumCalculatorApiResponse(){}
	public PremiumCalculatorApiResponse(PremiumCalculatorResponse response) {
		this.response = response;
	}
	public PremiumCalculatorResponse getResponse() {
		return response;
	}
	public void setResponse(PremiumCalculatorResponse response) {
		this.response = response;
	}
	
	@Override
	public String toString() {
		return "PremiumCalculatorApiResponse [response=" + response + "]";
	}
	

}
