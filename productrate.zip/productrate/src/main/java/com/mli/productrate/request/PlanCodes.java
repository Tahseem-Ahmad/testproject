package com.mli.productrate.request;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class PlanCodes implements Serializable{
	private static final long serialVersionUID = 1L;
	
	Logger logger =Logger.getLogger(PlanCodes.class);
	
	@Autowired
	Environment env;
	
	private boolean initialized = false;
	
	private String planTcot60;
	private List<String> plancodelistTCOT60TNOT60;
	private List<String> plancodelistTCOTP2TNOTP2;
	private List<String> plancodelistTCCIBTNCIB;
	private List<String> plancodelistDCCCP;
	private List<String> plancodelistVN05VN04;
	private List<String> plancodelistTCCPABTNCPAB;
	private List<String> planIdforDB;
	private List<String> riderIdforDB;
	public PlanCodes() 
	{
		super();
	}

	public void initialize()
	{
		if(!initialized)
		{
			try 
			{
				logger.debug("Fetching required information from resource i.e. configured property : Start");
				planTcot60 ="TCOT60";
				plancodelistTCOT60TNOT60 = Arrays.asList(env.getProperty("plancode.TCOT60.TNOT60").split(","));
				plancodelistTCOTP2TNOTP2 =Arrays.asList(env.getProperty("plancode.TCOTP2.TNOTP2").split(","));
				plancodelistTCCIBTNCIB =Arrays.asList(env.getProperty("plancode.TCCIB.TNCIB").split(","));
				plancodelistDCCCP = Arrays.asList(env.getProperty("plancode.DCCCP").split(","));
				plancodelistVN05VN04 = Arrays.asList(env.getProperty("plancode.VN05.VN04").split(","));
				plancodelistTCCPABTNCPAB = Arrays.asList(env.getProperty("plancode.TCCPAB.TNCPAB").split(","));
				planIdforDB =Arrays.asList(env.getProperty("planCodeforDB.productCode").split(","));
				riderIdforDB = Arrays.asList(env.getProperty("riderIdforDB.productCode").split(","));
				initialized=true;
				logger.debug("Fetching required information from resource i.e. configured property : End");
			}
			catch (Exception e) 
			{
				logger.error("Getting exception while Fetching required information from resource i.e. configured property : "+e);
			}
		}
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public String getPlanTcot60() {
		return planTcot60;
	}

	public void setPlanTcot60(String planTcot60) {
		this.planTcot60 = planTcot60;
	}

	public List<String> getPlancodelistTCOT60TNOT60() {
		return plancodelistTCOT60TNOT60;
	}

	public void setPlancodelistTCOT60TNOT60(List<String> plancodelistTCOT60TNOT60) {
		this.plancodelistTCOT60TNOT60 = plancodelistTCOT60TNOT60;
	}

	public List<String> getPlancodelistTCOTP2TNOTP2() {
		return plancodelistTCOTP2TNOTP2;
	}

	public void setPlancodelistTCOTP2TNOTP2(List<String> plancodelistTCOTP2TNOTP2) {
		this.plancodelistTCOTP2TNOTP2 = plancodelistTCOTP2TNOTP2;
	}

	public List<String> getPlancodelistTCCIBTNCIB() {
		return plancodelistTCCIBTNCIB;
	}

	public void setPlancodelistTCCIBTNCIB(List<String> plancodelistTCCIBTNCIB) {
		this.plancodelistTCCIBTNCIB = plancodelistTCCIBTNCIB;
	}

	public List<String> getPlancodelistDCCCP() {
		return plancodelistDCCCP;
	}

	public void setPlancodelistDCCCP(List<String> plancodelistDCCCP) {
		this.plancodelistDCCCP = plancodelistDCCCP;
	}

	public List<String> getPlancodelistVN05VN04() {
		return plancodelistVN05VN04;
	}

	public void setPlancodelistVN05VN04(List<String> plancodelistVN05VN04) {
		this.plancodelistVN05VN04 = plancodelistVN05VN04;
	}

	public List<String> getPlancodelistTCCPABTNCPAB() {
		return plancodelistTCCPABTNCPAB;
	}

	public void setPlancodelistTCCPABTNCPAB(List<String> plancodelistTCCPABTNCPAB) {
		this.plancodelistTCCPABTNCPAB = plancodelistTCCPABTNCPAB;
	}

	public List<String> getPlanIdforDB() {
		return planIdforDB;
	}

	public void setPlanIdforDB(List<String> planIdforDB) {
		this.planIdforDB = planIdforDB;
	}

	public List<String> getRiderIdforDB() {
		return riderIdforDB;
	}

	public void setRiderIdforDB(List<String> riderIdforDB) {
		this.riderIdforDB = riderIdforDB;
	}

	@Override
	public String toString() {
		return "PlanCodes [logger=" + logger + ", env=" + env + ", initialized=" + initialized + ", planTcot60="
				+ planTcot60 + ", plancodelistTCOT60TNOT60=" + plancodelistTCOT60TNOT60 + ", plancodelistTCOTP2TNOTP2="
				+ plancodelistTCOTP2TNOTP2 + ", plancodelistTCCIBTNCIB=" + plancodelistTCCIBTNCIB
				+ ", plancodelistDCCCP=" + plancodelistDCCCP + ", plancodelistVN05VN04=" + plancodelistVN05VN04
				+ ", plancodelistTCCPABTNCPAB=" + plancodelistTCCPABTNCPAB + ", planIdforDB=" + planIdforDB
				+ ", riderIdforDB=" + riderIdforDB + "]";
	}
	
	

}
