package com.mli.productrate.request;

import java.io.Serializable;
import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class PlanCodes implements Serializable{
	private static final long serialVersionUID = 1L;
	
	Logger logger =Logger.getLogger(PlanCodes.class);
	
	
	@Value("${plancode.TCOT60}")
	private String planTcot60;
	
	@Value("${plancode.TCOT60.TNOT60}")
	private List<String> plancodelistTCOT60TNOT60;
	
	@Value("${plancode.TCOTP2.TNOTP2}")
	private List<String> plancodelistTCOTP2TNOTP2;
	
	@Value("${plancode.TCCIB.TNCIB}")
	private List<String> plancodelistTCCIBTNCIB;
	
	@Value("${plancode.DCCCP}")
	private List<String> plancodelistDCCCP;
	
	@Value("${plancode.VN05.VN04}")
	private List<String> plancodelistVN05VN04;
	
	@Value("${plancode.TCCPAB.TNCPAB}")
	private List<String> plancodelistTCCPABTNCPAB;
	
	@Value("${planCodeforDB.productCode}")
	private List<String> planIdforDB;
	
	@Value("${riderIdforDB.productCode}")
	private List<String> riderIdforDB;
	

	public String getPlanTcot60() {
		return planTcot60;
	}

	public void setPlanTcot60(String planTcot60) {
		this.planTcot60 = planTcot60;
	}

	public List<String> getPlancodelistTCOT60TNOT60() {
		return plancodelistTCOT60TNOT60;
	}

	public void setPlancodelistTCOT60TNOT60(List<String> plancodelistTCOT60TNOT60) {
		this.plancodelistTCOT60TNOT60 = plancodelistTCOT60TNOT60;
	}

	public List<String> getPlancodelistTCOTP2TNOTP2() {
		return plancodelistTCOTP2TNOTP2;
	}

	public void setPlancodelistTCOTP2TNOTP2(List<String> plancodelistTCOTP2TNOTP2) {
		this.plancodelistTCOTP2TNOTP2 = plancodelistTCOTP2TNOTP2;
	}

	public List<String> getPlancodelistTCCIBTNCIB() {
		return plancodelistTCCIBTNCIB;
	}

	public void setPlancodelistTCCIBTNCIB(List<String> plancodelistTCCIBTNCIB) {
		this.plancodelistTCCIBTNCIB = plancodelistTCCIBTNCIB;
	}

	public List<String> getPlancodelistDCCCP() {
		return plancodelistDCCCP;
	}

	public void setPlancodelistDCCCP(List<String> plancodelistDCCCP) {
		this.plancodelistDCCCP = plancodelistDCCCP;
	}

	public List<String> getPlancodelistVN05VN04() {
		return plancodelistVN05VN04;
	}

	public void setPlancodelistVN05VN04(List<String> plancodelistVN05VN04) {
		this.plancodelistVN05VN04 = plancodelistVN05VN04;
	}

	public List<String> getPlancodelistTCCPABTNCPAB() {
		return plancodelistTCCPABTNCPAB;
	}

	public void setPlancodelistTCCPABTNCPAB(List<String> plancodelistTCCPABTNCPAB) {
		this.plancodelistTCCPABTNCPAB = plancodelistTCCPABTNCPAB;
	}

	public List<String> getPlanIdforDB() {
		return planIdforDB;
	}

	public void setPlanIdforDB(List<String> planIdforDB) {
		this.planIdforDB = planIdforDB;
	}

	public List<String> getRiderIdforDB() {
		return riderIdforDB;
	}

	public void setRiderIdforDB(List<String> riderIdforDB) {
		this.riderIdforDB = riderIdforDB;
	}

	@Override
	public String toString() {
		return "PlanCodes [planTcot60=" + planTcot60 + ", plancodelistTCOT60TNOT60=" + plancodelistTCOT60TNOT60
				+ ", plancodelistTCOTP2TNOTP2=" + plancodelistTCOTP2TNOTP2 + ", plancodelistTCCIBTNCIB="
				+ plancodelistTCCIBTNCIB + ", plancodelistDCCCP=" + plancodelistDCCCP + ", plancodelistVN05VN04="
				+ plancodelistVN05VN04 + ", plancodelistTCCPABTNCPAB=" + plancodelistTCCPABTNCPAB + ", planIdforDB="
				+ planIdforDB + ", riderIdforDB=" + riderIdforDB + "]";
	}

	

	
	

}
