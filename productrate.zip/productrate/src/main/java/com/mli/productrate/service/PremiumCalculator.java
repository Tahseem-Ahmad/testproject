package com.mli.productrate.service;

import com.mli.productrate.request.PremiumCalculatorAPIRequest;
import com.mli.productrate.response.PremiumCalculatorApiResponse;

public interface PremiumCalculator {
  public PremiumCalculatorApiResponse calculatePremium(PremiumCalculatorAPIRequest premiumCalculatorAPIRequest); 
}
