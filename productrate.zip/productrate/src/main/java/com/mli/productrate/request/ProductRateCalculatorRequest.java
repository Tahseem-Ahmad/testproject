package com.mli.productrate.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

import com.mli.productrate.util.Header;


public class ProductRateCalculatorRequest implements Serializable{
	private static final long serialVersionUID = 1L;
	@NotEmpty(message="Header is mandatory field")
	private Header header;
	
	@NotEmpty(message="Payload is mandatory field")
	private RequestPayload payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public RequestPayload getPayload() {
		return payload;
	}
	public void setPayload(RequestPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "PremiumCalculatorRequest [header=" + header + ", payload=" + payload + "]";
	}
	

}
