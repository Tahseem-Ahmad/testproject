package com.mli.productrate.service;

import java.util.List;
import java.util.Map;

import com.mli.productrate.response.PlanDetailBean;

public interface PlanDetail {
	public List<PlanDetailBean> callPlanDetailService(String planId,String rtblAgeDur,String rtblSex);

	public List<Map<String , String>> getPlancDetails(String plans, String rtblAgeDur, String rtblSex, String empDiscount,String serviceName);

}
