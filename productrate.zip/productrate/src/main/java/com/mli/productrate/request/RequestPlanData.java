package com.mli.productrate.request;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;

/**
 * @author ad01084
 *
 */
public class RequestPlanData implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@NotEmpty(message="PlandId is mandatory field")
	private String planId ;
	private String variantId ; 
	private String gender ;
	private String age ;
	private String empDiscount ;
	private String planSumAssured ;
	private String policyTerm ;
	private String policyPayTerm ;
	private String smoke ;
	private String mode ;
	public RequestPlanData(){
		
	}
	public RequestPlanData(String planId, String variantId, String gender, String age, String empDiscount,
			String planSumAssured, String policyTerm, String policyPayTerm, String smoke, String mode) {
		super();
		this.planId = planId;
		this.variantId = variantId;
		this.gender = gender;
		this.age = age;
		this.empDiscount = empDiscount;
		this.planSumAssured = planSumAssured;
		this.policyTerm = policyTerm;
		this.policyPayTerm = policyPayTerm;
		this.smoke = smoke;
		this.mode = mode;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getVariantId() {
		return variantId;
	}
	public void setVariantId(String variantId) {
		this.variantId = variantId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmpDiscount() {
		return empDiscount;
	}
	public void setEmpDiscount(String empDiscount) {
		this.empDiscount = empDiscount;
	}
	public String getPlanSumAssured() {
		return planSumAssured;
	}
	public void setPlanSumAssured(String planSumAssured) {
		this.planSumAssured = planSumAssured;
	}
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPolicyPayTerm() {
		return policyPayTerm;
	}
	public void setPolicyPayTerm(String policyPayTerm) {
		this.policyPayTerm = policyPayTerm;
	}
	public String getSmoke() {
		return smoke;
	}
	public void setSmoke(String smoke) {
		this.smoke = smoke;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	@Override
	public String toString() {
		return "ReqPlanData [planId=" + planId + ", variantId=" + variantId + ", gender=" + gender + ", age=" + age
				+ ", empDiscount=" + empDiscount + ", planSumAssured=" + planSumAssured + ", policyTerm=" + policyTerm
				+ ", policyPayTerm=" + policyPayTerm + ", smoke=" + smoke + ", mode=" + mode + "]";
	}
}
