package com.mli.productrate.service;

import com.mli.productrate.request.ProductRateCalculatorApiRequest;
import com.mli.productrate.response.ProductRateCalculatorApiResponse;

public interface ProductRateCalulator {
  public ProductRateCalculatorApiResponse calculateProductRate(ProductRateCalculatorApiRequest premiumCalculatorAPIRequest); 
}
