package com.mli.productrate.request;

import java.io.Serializable;

public class ProductRateCalculatorApiRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
    private ProductRateCalculatorRequest request;
	public ProductRateCalculatorRequest getRequest() {
		return request;
	}
	public void setRequest(ProductRateCalculatorRequest request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "PremiumCalculatorAPIRequest [request=" + request + "]";
	}
    
}
