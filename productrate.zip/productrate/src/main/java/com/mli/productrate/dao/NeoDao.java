package com.mli.productrate.dao;

import java.util.List;

import com.mli.productrate.response.PlanDetailBean;

public interface NeoDao {
	public List<PlanDetailBean> callPlanDetail(String planid, String rtblAgeDur, String rtblSex);

	public List<Object[]> callPlanDetailsV2(String plans, String rtblAgeDur, String rtblSex, String empDiscount);
}
