package com.qc.utils;

import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
@Component
public class UniqueId 
{
	
	private static Logger logger = LogManager.getLogger(UniqueId.class);
	public static String getUniqueId()
	{
		UUID uniqueId = UUID.randomUUID();
		return ""+uniqueId;
	}
	
	public static Integer getIntegerFromString(String intData)
	{
		try
		{
			return Integer.parseInt(intData);
		}
		catch(Exception ex)
		{
			logger.error("Error while parsing string data to integer mannual return data : 999999 : Error Is : "+ex);
			return 999999;
		}
	}
}
