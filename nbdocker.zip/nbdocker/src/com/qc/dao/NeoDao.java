package com.qc.dao;

import java.util.List;

import com.qc.entity.PlanDetailBean;

public interface NeoDao 
{
	public List<PlanDetailBean> callPlanDetail(String planid, String rtbl_age_dur, String rtbl_sex);

	public List<Object[]> callPlanDetailsV2(String plans, String rtblAgeDur, String rtblSex, String empDiscount);

}
