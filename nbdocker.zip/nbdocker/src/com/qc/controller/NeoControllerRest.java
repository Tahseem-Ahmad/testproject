package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.request.premiumcalc.ApiRequestpremiumCalc;
import com.qc.api.response.premiumcalc.ApiResponsepremiumCalc;
import com.qc.service.NeoPremiumCalcService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author ad01084
 *
 */
@RestController
@RequestMapping(value = "/neo/api")
@Api(value="NEO", description="NEO service for maxlifeinsurance.com",tags = {"NEO"})
public class NeoControllerRest 
{
	private static Logger logger = LogManager.getLogger(NeoControllerRest.class);

	@Autowired NeoPremiumCalcService neoPremiumCalcService;

	@Autowired DozerBeanMapper dozerBeanMapper;

	@ApiOperation(notes = "This service is used to find premium calculation ", value = "values is required to get  premium calculation!", nickname = "")
	@RequestMapping(value = "/v1/premiumcalculation", method = RequestMethod.POST, consumes = { "application/json" }, produces = {"application/json" })
	public ApiResponsepremiumCalc getPremiumCalculation(@Valid @RequestBody ApiRequestpremiumCalc apiRequest)
	{
		logger.info( "NeoControllerRest:: getPremiumCalculation");
		return neoPremiumCalcService.premiumCalculatorService(apiRequest);
	}
}
