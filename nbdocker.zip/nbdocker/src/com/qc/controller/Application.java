package com.qc.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.MessageSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

/**
 * @author ad01084
 *
 */

@SpringBootApplication(scanBasePackages = { "com.qc" },exclude= MessageSourceAutoConfiguration.class)
//@EnableMongoRepositories(basePackages = "com.qc.mongo.repository")
@PropertySources({
//	@PropertySource(value="classpath:application.properties"),
	@PropertySource(value="file:/mount_app/config_repo/nb/application_nb.properties",ignoreResourceNotFound=true),
	@PropertySource(value="file:/mount_app/config_repo/nb/servicesDbDetails_nb.properties",ignoreResourceNotFound=true)
//	,@PropertySource(value="file:D:/mount_app/config_repo/nb/application_nb.properties",ignoreResourceNotFound=true)
})
public class Application extends SpringBootServletInitializer
{
	private static final Logger logger = LogManager.getLogger(Application.class);
	public Application()
	{
		super();
		setRegisterErrorPageFilter(false);
		logger.info("setRegisterErrorPageFilter as false");
	}
	
	protected SpringApplicationBuilder configure(SpringApplicationBuilder applicationBuilder)
	{
		return applicationBuilder.sources(Application.class);
	}
	
	
	/**
	 * @author ad01084
	 * WAS CONFIG : need to comment below method when we have to run this on WAS server Also need to exclude some parts in pom.xml where also comments written
	 * Tomcat Config : Need to uncomment below method when we have to run spring boot in tomcat
	 *
	 */
	public static void main(String[] args) throws Exception 
	{
		logger.info("SpringBoot Application : Start");
		SpringApplication.run(Application.class, args);
	}
}
