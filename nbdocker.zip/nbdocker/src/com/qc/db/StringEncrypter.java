package com.qc.db;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.itextpdf.text.DocumentException;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
/**
 * @author ad01084
 * Utility Program for encrypting and decrypting strings
 *
 */
public class StringEncrypter 
{
	private static Logger logger = LogManager.getLogger(StringEncrypter.class);
	private static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	private static final String DES_ENCRYPTION_SCHEME = "DES";
	private static final String DEFAULT_ENCRYPTION_KEY = "This is a fairly long phrase used to encrypt";
	private static final String UNICODE_FORMAT = "UTF8";
	private KeySpec keySpec;
	private SecretKeyFactory keyFactory;
	private static final String DEFAULT_ENCRYPTION_KEY1 = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
	private Cipher cipher;

	public StringEncrypter() throws NoSuchPaddingException,NoSuchAlgorithmException,UnsupportedEncodingException, InvalidKeyException
	{
		this(DES_ENCRYPTION_SCHEME, DEFAULT_ENCRYPTION_KEY1);
	}
	/**
	 * Constructor that internally uses a default encryption key
	 * 
	 * @param encryptionScheme
	 *            the encryption scheme to be used. Pass one of the encryption
	 *            schemes defined in this class
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public StringEncrypter(String encryptionScheme) throws NoSuchPaddingException,NoSuchAlgorithmException,UnsupportedEncodingException,UnsupportedEncodingException, InvalidKeyException 
	{
		this(encryptionScheme, DEFAULT_ENCRYPTION_KEY);
	}

	/**
	 * Constructor that uses the provided encryption key
	 * 
	 * @param encryptionScheme
	 *            the encryption scheme to be used. Pass one of the encryption
	 *            schemes defined in this class
	 * @param encryptionKey
	 *            encryption key to be used. While decrypting a string, the same
	 *            key used for encryption must be used
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public StringEncrypter(String encryptionScheme, String encryptionKey)throws  UnsupportedEncodingException,InvalidKeyException,NoSuchAlgorithmException,NoSuchPaddingException
	{
		if (encryptionKey == null) 
		{
			throw new IllegalArgumentException("Encryption key was null");
		}
		if (encryptionKey.trim().length() < 24) 
		{
			throw new IllegalArgumentException("Encryption key was less than 24 characters");
		}
		try 
		{
			byte[] keyAsBytes = encryptionKey.getBytes(UNICODE_FORMAT);

			if (encryptionScheme.equals(DESEDE_ENCRYPTION_SCHEME)) 
			{
				keySpec = new DESedeKeySpec(keyAsBytes);
			}
			else if (encryptionScheme.equals(DES_ENCRYPTION_SCHEME)) 
			{
				keySpec = new DESKeySpec(keyAsBytes);
			}
			else 
			{
				throw new IllegalArgumentException("Encryption scheme not supported: " + encryptionScheme);
			}
			keyFactory = SecretKeyFactory.getInstance(encryptionScheme);
			cipher = Cipher.getInstance(encryptionScheme);
		}
		catch(InvalidKeyException e)
		{
			logger.error("Exception is "+e);
			throw new InvalidKeyException(e);
		}
		catch(UnsupportedEncodingException e)
		{
			logger.error("Exception is "+e);
			throw new UnsupportedEncodingException();
		}
		catch(NoSuchAlgorithmException e)
		{
			logger.error("Exception is "+e);
			throw new NoSuchAlgorithmException(e);
		}
		catch(NoSuchPaddingException e)
		{
			logger.error("Exception is "+e);
			throw new NoSuchPaddingException();
		}
	}

	/**
	 * Encrypt a string
	 * 
	 * @param unencryptedString
	 *            the string to be encrypted
	 * @return the encrypted string
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String encrypt(String unencryptedString)  throws InvalidKeyException ,InvalidKeySpecException, UnsupportedEncodingException,IllegalBlockSizeException,BadPaddingException
	{
		if ((unencryptedString == null)	|| (unencryptedString.trim().length() == 0)) 
		{
			throw new IllegalArgumentException("unencrypted string was null or empty");
		}
		try 
		{
			SecretKey key = keyFactory.generateSecret(keySpec);
			cipher.init(Cipher.ENCRYPT_MODE, key);

			byte[] cleartext = unencryptedString.getBytes(UNICODE_FORMAT);
			byte[] ciphertext = cipher.doFinal(cleartext);

			BASE64Encoder base64encoder = new BASE64Encoder();

			return base64encoder.encode(ciphertext);
		}
		catch (InvalidKeyException e) 
		{
			logger.error("Exception is "+ e);
			throw new InvalidKeyException(e);
		}
		catch (InvalidKeySpecException e) 
		{
			logger.error("Exception is "+ e);
			throw new InvalidKeySpecException(e);
		}
		catch (UnsupportedEncodingException e) 
		{
			logger.error("Exception is "+ e);
			throw new UnsupportedEncodingException();
		} 
		catch (IllegalStateException e) 
		{
			logger.error("Exception is "+ e);
			throw new IllegalStateException(e);
		}
		catch (IllegalBlockSizeException e) 
		{
			logger.error("Exception is "+ e);
			throw new IllegalBlockSizeException();
		} 
		catch (BadPaddingException e) 
		{
			logger.error("Exception is "+ e);
			throw new BadPaddingException();
		}
	}

	/**
	 * Decrypt a string that was encrypted by this utility earlier
	 * 
	 * @param encryptedString
	 *            the string to be decrypted
	 * @return the decrypted string
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String decrypt(String encryptedString) throws InvalidKeyException,InvalidKeySpecException,IllegalBlockSizeException,BadPaddingException,IOException
	{
		if ((encryptedString == null) || (encryptedString.trim().length() <= 0)) 
		{
			throw new  IllegalArgumentException("encrypted string was null or empty");
		}
		try 
		{
			SecretKey key = keyFactory.generateSecret(keySpec);
			cipher.init(Cipher.DECRYPT_MODE, key);

			BASE64Decoder base64decoder = new BASE64Decoder();
			byte[] cleartext = base64decoder.decodeBuffer(encryptedString);
			byte[] ciphertext = cipher.doFinal(cleartext);

			return bytes2String(ciphertext);
		}
		catch (InvalidKeyException e) 
		{
			logger.error("Exception is "+ e);
			throw new InvalidKeyException(e);
		}
		catch (InvalidKeySpecException e) 
		{
			logger.error("Exception is "+ e);
			throw new InvalidKeySpecException(e);
		}
		catch (IllegalStateException e) 
		{
			logger.error("Exception is "+ e);
			throw new IllegalStateException(e);
		}
		catch (IllegalBlockSizeException e) 
		{
			logger.error("Exception is "+ e);
			throw new IllegalBlockSizeException();
		}
		catch (BadPaddingException e) 
		{
			logger.error("Exception is "+ e);
			throw new BadPaddingException();
		}
		catch (IOException e) 
		{
			logger.error("Exception is "+ e);
			throw new IOException(e);
		}
	}

	private static String bytes2String(byte[] bytes) 
	{
		StringBuilder stringBuilder = new StringBuilder();

		for (int i = 0; i < bytes.length; i++) 
		{
			stringBuilder.append((char) bytes[i]);
		}
		return stringBuilder.toString();
	}

	/**
	 * Use this method for generating encrypted strings.
	 * 
	 * @param args
	 *            Provide the string to be encrypted
	 * @exception DocumentException
	 *                any exception thrown in this method will be wrapped in an
	 *                PortalException and thrown again
	 */
	public String getPassword(String args) throws NoSuchPaddingException,IOException,  NoSuchAlgorithmException,InvalidKeyException, BadPaddingException, IllegalBlockSizeException,InvalidKeySpecException
	{		
		String encryptionKey = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
		String encryptionScheme = StringEncrypter.DES_ENCRYPTION_SCHEME;
		StringEncrypter encrypter = new StringEncrypter(encryptionScheme,encryptionKey);				
		return encrypter.decrypt(args);		
	}

	public String decryptPassword(String args) throws NoSuchPaddingException,IOException,  NoSuchAlgorithmException,InvalidKeyException, BadPaddingException, IllegalBlockSizeException,InvalidKeySpecException
	{		
		String encryptionKey = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
		String encryptionScheme = StringEncrypter.DES_ENCRYPTION_SCHEME;
		StringEncrypter encrypter = new StringEncrypter(encryptionScheme,encryptionKey);				
		return encrypter.decrypt(args);		
	}	

	public static void main(String []args)
	{		
		Logger logger = LogManager.getLogger(StringEncrypter.class);
		try
		{
			System.out.println("Decripted Pwd: "+new StringEncrypter().decrypt("/XhLAcJx/oNRaLi6kc10Zg=="));
			System.out.println("Encrypted = "+new StringEncrypter().encrypt("soauat#123"));		
		}
		catch(Exception ex)
		{
			logger.error(ex);
		}
	}
}