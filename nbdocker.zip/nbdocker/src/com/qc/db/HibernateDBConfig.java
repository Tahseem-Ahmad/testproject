package com.qc.db;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * @author ad01084
 *
 */
@Configuration
@ImportResource({ "classpath*:DataSource.xml", "classpath*:Hibernate.xml" })
@PropertySource({"file:/mount_app/config_repo/nb/dbConfig_nb.properties"})
public class HibernateDBConfig {

	public HibernateDBConfig() {
		super();
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() {
		final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
		return pspc;
	}
}
