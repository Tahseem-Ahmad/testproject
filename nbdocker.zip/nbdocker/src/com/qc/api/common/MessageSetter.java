package com.qc.api.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class MessageSetter {

	private MessageSetter() {}

	private static Logger logger = LogManager.getLogger(MessageSetter.class);

	public static void setMessage(MsgInfo msgInfo, String msgCode, String msg, String msgDescription) {
		msgInfo.setMsg(msg);
		msgInfo.setMsgCode(msgCode);
		msgInfo.setMsgDescription(msgDescription);
		logger.info(msgDescription);
	}

	public static void setErrorMessage(MsgInfo msgInfo, String msgCode, String msg, String msgDescription,
			Exception ex) {
		msgInfo.setMsg(msg);
		msgInfo.setMsgCode(msgCode);
		msgInfo.setMsgDescription(msgDescription);
		logger.error(msgDescription + " : " + ex);
	}

}
