package com.qc.api.response.premiumcalc;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponsepremiumCalc implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private Header header;
	private MsgInfo msgInfo;
	private ResPayload payload; 

	public ResponsepremiumCalc() {
		super();
	}
	public ResponsepremiumCalc(Header header, MsgInfo msgInfo, ResPayload payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public Header getHeader() {
		return header;
	}

	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public ResPayload getPayload() {
		return payload;
	}

	public void setPayload(ResPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponsepremiumCalc [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
	}