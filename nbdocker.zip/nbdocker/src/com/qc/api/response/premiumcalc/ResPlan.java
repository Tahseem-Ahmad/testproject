package com.qc.api.response.premiumcalc;

import java.io.Serializable;
import java.util.List;

public class ResPlan implements Serializable 
{
	private static final long serialVersionUID = 2504004817515934483L;
	
	private String totalPremiumWOGST;
	private String totalPremiumWGST;
	private String planBasePremium ;
	private String planWGST ;
	private String planId ;
	private String variantId ; 
	private String gender ;
	private String age ;
	private String empDiscount ;
	private String planSumAssured ;
	private String policyTerm ;
	private String policyPayTerm ;
	private String smoke ;
	
	private String mode;
	private String totalRiderPremiumWGST;
	private String totalRiderPremiumWOGST;  
	private String planGST;  
	private List<ResRider> resRider;

	
	public String getPlanGST() {
		return planGST;
	}

	public void setPlanGST(String planGST) {
		this.planGST = planGST;
	}

	public String getTotalRiderPremiumWGST() {
		return totalRiderPremiumWGST;
	}

	public void setTotalRiderPremiumWGST(String totalRiderPremiumWGST) {
		this.totalRiderPremiumWGST = totalRiderPremiumWGST;
	}

	public String getTotalRiderPremiumWOGST() {
		return totalRiderPremiumWOGST;
	}

	public void setTotalRiderPremiumWOGST(String totalRiderPremiumWOGST) {
		this.totalRiderPremiumWOGST = totalRiderPremiumWOGST;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getVariantId() {
		return variantId;
	}

	public void setVariantId(String variantId) {
		this.variantId = variantId;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getEmpDiscount() {
		return empDiscount;
	}

	public void setEmpDiscount(String empDiscount) {
		this.empDiscount = empDiscount;
	}

	public String getPlanSumAssured() {
		return planSumAssured;
	}

	public void setPlanSumAssured(String planSumAssured) {
		this.planSumAssured = planSumAssured;
	}

	public String getPolicyTerm() {
		return policyTerm;
	}

	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}

	public String getPolicyPayTerm() {
		return policyPayTerm;
	}

	public void setPolicyPayTerm(String policyPayTerm) {
		this.policyPayTerm = policyPayTerm;
	}

	public String getSmoke() {
		return smoke;
	}

	public void setSmoke(String smoke) {
		this.smoke = smoke;
	}

	public String getPlanBasePremium() {
		return planBasePremium;
	}

	public void setPlanBasePremium(String planBasePremium) {
		this.planBasePremium = planBasePremium;
	}

	public String getPlanWGST() {
		return planWGST;
	}

	public void setPlanWGST(String planWGST) {
		this.planWGST = planWGST;
	}

	public List<ResRider> getResRider() {
		return resRider;
	}

	public void setResRider(List<ResRider> resRider) {
		this.resRider = resRider;
	}

	public String getTotalPremiumWGST() {
		return totalPremiumWGST;
	}

	public void setTotalPremiumWGST(String totalPremiumWGST) {
		this.totalPremiumWGST = totalPremiumWGST;
	}

	public String getTotalPremiumWOGST() {
		return totalPremiumWOGST;
	}

	public void setTotalPremiumWOGST(String totalPremiumWOGST) {
		this.totalPremiumWOGST = totalPremiumWOGST;
	}

	@Override
	public String toString() {
		return "ResPlan [totalPremiumWOGST=" + totalPremiumWOGST + ", totalPremiumWGST=" + totalPremiumWGST
				+ ", planBasePremium=" + planBasePremium + ", planWGST=" + planWGST + ", planId=" + planId
				+ ", variantId=" + variantId + ", gender=" + gender + ", age=" + age + ", empDiscount=" + empDiscount
				+ ", planSumAssured=" + planSumAssured + ", policyTerm=" + policyTerm + ", policyPayTerm="
				+ policyPayTerm + ", smoke=" + smoke + ", mode=" + mode + ", totalRiderPremiumWGST="
				+ totalRiderPremiumWGST + ", totalRiderPremiumWOGST=" + totalRiderPremiumWOGST + ", planGST=" + planGST
				+ ", resRider=" + resRider + "]";
	}

	
	

}

