package com.qc.api.response.premiumcalc;

import java.io.Serializable;

public class ResRider implements Serializable 
{
	private static final long serialVersionUID = 2504004817515934483L;
	
	private String riderWGST="";
	private String riderPremium="";
	private String riderId = "";
	private String riderSA = ""; 
	private String riderTerm = "";
	private String riderGST = "";
//	private String totalRiderPremiumWGST;
//	private String totalRiderPremiumWOGST;   
	
	
	public String getRiderId() {
		return riderId;
	}


	public String getRiderGST() {
		return riderGST;
	}


	public void setRiderGST(String riderGST) {
		this.riderGST = riderGST;
	}


	public void setRiderId(String riderId) {
		this.riderId = riderId;
	}


	public String getRiderSA() {
		return riderSA;
	}


	public void setRiderSA(String riderSA) {
		this.riderSA = riderSA;
	}


	public String getRiderTerm() {
		return riderTerm;
	}


	public void setRiderTerm(String riderTerm) {
		this.riderTerm = riderTerm;
	}


//	public String getTotalRiderPremiumWGST() {
//		return totalRiderPremiumWGST;
//	}
//
//
//	public void setTotalRiderPremiumWGST(String totalRiderPremiumWGST) {
//		this.totalRiderPremiumWGST = totalRiderPremiumWGST;
//	}
//
//
//	public String getTotalRiderPremiumWOGST() {
//		return totalRiderPremiumWOGST;
//	}
//
//
//	public void setTotalRiderPremiumWOGST(String totalRiderPremiumWOGST) {
//		this.totalRiderPremiumWOGST = totalRiderPremiumWOGST;
//	}


	public String getRiderWGST() {
		return riderWGST;
	}


	public void setRiderWGST(String riderWGST) {
		this.riderWGST = riderWGST;
	}


	public String getRiderPremium() {
		return riderPremium;
	}


	public void setRiderPremium(String riderPremium) {
		this.riderPremium = riderPremium;
	
	}


	@Override
	public String toString() {
		return "ResRider [riderWGST=" + riderWGST + ", riderPremium=" + riderPremium + ", riderId=" + riderId
				+ ", riderSA=" + riderSA + ", riderTerm=" + riderTerm + ", riderGST=" + riderGST + "]";
	}


	

	
}
	