package com.qc.api.response.premiumcalc;

import java.io.Serializable;



public class ApiResponsepremiumCalc implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private ResponsepremiumCalc response;
	public ApiResponsepremiumCalc() {
		super();
	}
	public ApiResponsepremiumCalc( ResponsepremiumCalc response) {
		super();
		this.response = response;
	}
	
	public ResponsepremiumCalc getResponse() {
		return response;
	}
	public void setResponse(ResponsepremiumCalc response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponsepremiumCalc [ response=" + response + "]";
	}
}
