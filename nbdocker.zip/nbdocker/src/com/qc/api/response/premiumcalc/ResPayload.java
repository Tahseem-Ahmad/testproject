package com.qc.api.response.premiumcalc;

import java.io.Serializable;
import java.util.List;


public class ResPayload implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private List<ResPlan> resPlan;

	public List<ResPlan> getResPlan() {
		return resPlan;
	}
	public void setResPlan(List<ResPlan> resPlan) {
		this.resPlan = resPlan;
	}
	@Override
	public String toString() {
		return "ResPayload [resPlan=" + resPlan + "]";
	}
}