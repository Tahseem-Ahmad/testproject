package com.qc.api.request;

import java.io.Serializable;

public class ProposalRequest implements Serializable {

	
	private static final long serialVersionUID = 345275244394710590L;
	private String proposalNumber;

	public String getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(String proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	
}
