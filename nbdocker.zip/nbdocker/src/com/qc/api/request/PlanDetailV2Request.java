package com.qc.api.request;

import java.io.Serializable;
import java.util.List;

public class PlanDetailV2Request implements Serializable{

	private static final long serialVersionUID = -530538252712204869L;
	transient private List<Object> plans;
	private String rtblSexCd;
	private String rtblAgeDur;
	private String empDiscount;
	private String validationType;
	
	public List<Object> getPlans() {
		return plans;
	}
	public void setPlans(List<Object> plans) {
		this.plans = plans;
	}
	public String getRtblSexCd() {
		return rtblSexCd;
	}
	public void setRtblSexCd(String rtblSexCd) {
		this.rtblSexCd = rtblSexCd;
	}
	public String getRtblAgeDur() {
		return rtblAgeDur;
	}
	public void setRtblAgeDur(String rtblAgeDur) {
		this.rtblAgeDur = rtblAgeDur;
	}
	public String getEmpDiscount() {
		return empDiscount;
	}
	public void setEmpDiscount(String empDiscount) {
		this.empDiscount = empDiscount;
	}
	public String getValidationType() {
		return validationType;
	}
	public void setValidationType(String validationType) {
		this.validationType = validationType;
	}
	
	
}
