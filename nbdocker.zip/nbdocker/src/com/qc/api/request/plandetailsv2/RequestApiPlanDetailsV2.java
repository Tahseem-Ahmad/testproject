package com.qc.api.request.plandetailsv2;

import com.qc.api.request.ReqHeader;

public class RequestApiPlanDetailsV2
{

private ReqHeader header;
private PayloadReqPlanDetailsV2 payload;

public RequestApiPlanDetailsV2(ReqHeader header, PayloadReqPlanDetailsV2 payload) {
	super();
	this.header = header;
	this.payload = payload;
}

public ReqHeader getHeader() {
	return header;
}

public void setHeader(ReqHeader header) {
	this.header = header;
}

public PayloadReqPlanDetailsV2 getPayload() {
	return payload;
}

public void setPayload(PayloadReqPlanDetailsV2 payload) {
	this.payload = payload;
}

public RequestApiPlanDetailsV2() {
	super();
}



}
