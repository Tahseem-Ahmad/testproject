package com.qc.api.request.plandetailsv2;

import java.io.Serializable;
import java.util.List;

public class PayloadReqPlanDetailsV2 implements Serializable
{
	private static final long serialVersionUID = -5831430964787677588L;

	private List<RequestPlanDetailsV2> transactions;

	public List<RequestPlanDetailsV2> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<RequestPlanDetailsV2> transactions) {
		this.transactions = transactions;
	}
	@Override
	public String toString() {
		return "Payload [transactions=" + transactions + "]";
	}
	
}
