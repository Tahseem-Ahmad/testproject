package com.qc.api.request.plandetailsv2;

import java.io.Serializable;

public class Plans implements Serializable
{
	private static final long serialVersionUID = -2630951013722818617L;
	private String planId ;

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}
}
