package com.qc.api.request.premiumcalc;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestpremiumCalc implements Serializable 
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private Payload payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public Payload getPayload() {
		return payload;
	}
	public void setPayload(Payload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestpremiumCalc [header=" + header + ", payload=" + payload + "]";
	}
	
}
