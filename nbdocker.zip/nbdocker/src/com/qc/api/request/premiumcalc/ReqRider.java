package com.qc.api.request.premiumcalc;

import java.io.Serializable;

public class ReqRider implements Serializable 
{
	private static final long serialVersionUID = 2504004817515934483L;
	
	private String riderId ;
	private String riderSA; 
	private String riderTerm ;
	
	
	public String getRiderId() {
		return riderId;
	}


	public void setRiderId(String riderId) {
		this.riderId = riderId;
	}


	public String getRiderSA() {
		return riderSA;
	}


	public void setRiderSA(String riderSA) {
		this.riderSA = riderSA;
	}


	public String getRiderTerm() {
		return riderTerm;
	}


	public void setRiderTerm(String riderTerm) {
		this.riderTerm = riderTerm;
	}


	
	@Override
	public String toString() {
		return "Requestrider [riderId=" + riderId + ", riderSA=" + riderSA + ", riderTerm=" + riderTerm +  "]";
				
}
}