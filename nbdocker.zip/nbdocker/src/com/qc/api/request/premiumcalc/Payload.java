package com.qc.api.request.premiumcalc;

import java.io.Serializable;
import java.util.List;

public class Payload implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	private List<ReqPlan> reqPlan;
	public List<ReqPlan> getReqPlan() {
		return reqPlan;
	}
	public void setReqPlan(List<ReqPlan> reqPlan) {
		this.reqPlan = reqPlan;
	}
	@Override
	public String toString() {
		return "Payload [reqPlan=" + reqPlan + "]";
	}
	
	

}
