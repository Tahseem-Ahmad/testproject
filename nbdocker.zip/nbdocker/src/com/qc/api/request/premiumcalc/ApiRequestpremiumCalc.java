package com.qc.api.request.premiumcalc;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonProperty;


public class ApiRequestpremiumCalc implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestpremiumCalc request;
	public ApiRequestpremiumCalc() {
		super();
	}
	public ApiRequestpremiumCalc( RequestpremiumCalc request) {
		super();
		this.request = request;
	}
	public RequestpremiumCalc getRequest() {
		return request;
	}
	public void setRequest(RequestpremiumCalc request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestpremiumCalc [ request=" + request + "]";
	}
}
