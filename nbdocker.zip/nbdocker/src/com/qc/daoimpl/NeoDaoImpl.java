package com.qc.daoimpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.qc.dao.NeoDao;
import com.qc.entity.PlanDetailBean;
import com.qc.service.ObjectToPojoService;

import oracle.jdbc.OracleTypes;

/**
 * @author ad01084
 *
 */
@Repository
public class NeoDaoImpl implements NeoDao 
{

	private static final Logger logger = LogManager.getLogger(NeoDaoImpl.class);
	@Autowired DozerBeanMapper dozerBeanMapper;
	@Autowired ObjectToPojoService objectToPojoService;

	@Autowired
	Environment env;

	@Autowired
	DBConnections dbConn;

	public String removeSpecialChar(String str)
	{
		String returnStr="";
		returnStr=str.replaceAll("\\\\", "\\\\\\\\");	  /// backslash
		returnStr=returnStr.replaceAll("\"", "\\\\\"");   /// double quotes
		returnStr=returnStr.replaceAll("\b", "\\\\\b");   /// backspaceas
		returnStr=returnStr.replaceAll("\f", "\\\\\f");   ///form feed
		returnStr=returnStr.replaceAll("\n", "\\\\\n");   ///new line
		returnStr=returnStr.replaceAll("\r", "\\\\\r");   /// carriage return
		returnStr=returnStr.replaceAll("\t", "\\\\\t");   /// tab
		returnStr=returnStr.replaceAll("\\v", "\\\\\\v"); /// vertical tab
		return returnStr;
	}


	@Override
	public List<PlanDetailBean> callPlanDetail(String planid,String rtbl_age_dur,String rtbl_sex) 
	{
		logger.debug("Comes to callPlanDetail Method: ");        
		final List<PlanDetailBean> planDetailBeanList = new ArrayList<PlanDetailBean>();
		Session session = dbConn.getDbConnection(env.getProperty("/v1/PlanDetailsRequest"));
		Work work = new Work()
		{
			@Override
			public void execute(Connection con) throws SQLException
			{
				ResultSet rs =null;
				if(con!=null)
				{
					String procName= " { ? = call FN_NEO_RATE_WEB_SERVICE(?, ?, ?) } ";
					try(CallableStatement clblStmt = con.prepareCall(procName);)
					{
						logger.info("Proc Call - FN_NEO_RATE_WEB_SERVICE : Start");
						clblStmt.setQueryTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
						clblStmt.registerOutParameter(1, OracleTypes.CURSOR);
						clblStmt.setString(2, planid);
						clblStmt.setString(3, rtbl_age_dur);
						clblStmt.setString(4, rtbl_sex);
						clblStmt.execute();
						rs = (ResultSet) clblStmt.getObject(1);
						logger.info("Get Proc Call - FN_NEO_RATE_WEB_SERVICE : End");
						if(rs!= null)
						{
							do
							{
								PlanDetailBean planDetailBean = new PlanDetailBean();
								try
								{
									planDetailBean.setPLAN_ID(rs.getString("PLAN_ID")!=null?rs.getString("PLAN_ID").trim():"");
									planDetailBean.setRH_ID(rs.getString("RH_ID")!=null?rs.getString("RH_ID").trim():"");
									planDetailBean.setRTBL_ID(rs.getString("RTBL_ID")!=null?rs.getString("RTBL_ID").trim():"");
									planDetailBean.setRH_BAND_AMT(rs.getString("RH_BAND_AMT")!=null?rs.getString("RH_BAND_AMT").trim():"");//--
									planDetailBean.setRTBL_SEX_CD(rs.getString("RTBL_SEX_CD")!=null?rs.getString("RTBL_SEX_CD").trim():"");
									planDetailBean.setDISCOUNT_OPTION(rs.getString("DISCOUNT_OPTION")!=null?rs.getString("DISCOUNT_OPTION").trim():"");
									planDetailBean.setSMOKER_CODE(rs.getString("SMOKER_CODE")!=null?rs.getString("SMOKER_CODE").trim():"");
									planDetailBean.setRTBL_MAT_XPRY_DUR(rs.getString("RTBL_MAT_XPRY_DUR")!=null?rs.getString("RTBL_MAT_XPRY_DUR").trim():"");//--
									planDetailBean.setISSUE_AGE(rs.getString("ISSUE_AGE")!=null?rs.getString("ISSUE_AGE").trim():"");//--
									planDetailBean.setRTBL_AGE(rs.getString("RTBL_AGE")!=null?rs.getString("RTBL_AGE").trim():"");
									planDetailBean.setRTBL_1_RT(rs.getString("RTBL_1_RT")!=null?rs.getString("RTBL_1_RT").trim():"");//--
									planDetailBeanList.add(planDetailBean);
								}
								catch(Exception e)
								{
									if(e.getMessage().equalsIgnoreCase("ResultSet.next was not called"))
									{
										logger.info("ResultSet.next was not called Exception occured while setting records from db : "+e);
									}
									else
									{
										logger.error("Some exception occured while setting records from db : "+e);	
									}
								}
							}while (rs.next());
						}

					}    
					catch(Exception e)
					{				
						logger.error("SQL exception while closing resources in getPlanDetailData Method: "+e);
					}
					finally
					{
						if(rs!=null)
						{
							rs.close();
						}
					}
				}
				else
				{
					logger.error("Connection is Not Available Service unavailable.");				
				}	
			}
		};
		session.doWork(work);
		if(planDetailBeanList.size()==0)
		{
			logger.info("Plan Details set to null as its size is zero");
			return null;
		}
		return planDetailBeanList;
	}

	@Override
	public List<Object[]> callPlanDetailsV2(String plans, String rtblAgeDur, String rtblSex, String empDiscount)
	{
		logger.info("Inside NeoDaoImpl :: PROC :- callPlanDetailsV2 :: STARTS");
		try 
		{
			Session session = dbConn.getDbConnection(env.getProperty("/v2/plandetails"));
			session.getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			session.getTransaction().begin();
			ProcedureCall call = session.createStoredProcedureCall("PR_NEO_RATE_WEB_SERVICE_OTP");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(plans);
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(rtblAgeDur);
			call.registerParameter(3, String.class, ParameterMode.IN).bindValue(rtblSex);
			call.registerParameter(4, String.class, ParameterMode.IN).bindValue(empDiscount);
			call.registerParameter(5, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			session.getTransaction().commit();
			if (output.isResultSet()) 
			{
				@SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
				logger.info("Outside NeoDaoImpl :: PROC :- callPlanDetailsV2 :: SUCCESS :: ENDS");
				return result;
			}
		}
		catch (Exception ex) 
		{
			logger.error("Exception occured in callPlanDetailsV2 " + ex);
		}
		logger.info("Outside NeoDaoImpl :: PROC :- callPlanDetailsV2 :: END");
		return null;
	}
}
