package com.qc.daoimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Component;

/**
 * @author ad01084
 *
 */
@Component
public class DBConnections 
{
	private static final Logger logger = LogManager.getLogger(DBConnections.class);

	@Autowired
	@Qualifier("hibernateSessionFactory_StagCdc_Soauat")
	private LocalSessionFactoryBean sessionFactoryStagCdc_Soauat;

	public Session getDbConnection(String connectionName)
	{
		Session session = null;
		try
		{
			logger.info("Creating connection for :: " +connectionName);
			switch(connectionName)
			{
				case "STAGCDC_SOAUAT":
					session = sessionFactoryStagCdc_Soauat.getObject().getCurrentSession();
					logger.info("Connection created succesfully :: " +connectionName);
					break;
				default :
					logger.info(connectionName+ " : is not configured kindly configure it or call with correct name");
					break;
			}
		}
		catch(Exception ex)
		{
			logger.error("Exception occured while getting db connection for :: " +connectionName +" :: Exception is :: " +ex);
		}
		return session;
	}

}
