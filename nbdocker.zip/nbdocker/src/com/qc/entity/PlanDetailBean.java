package com.qc.entity;

import java.io.Serializable;

public class PlanDetailBean implements Serializable
{
	private static final long serialVersionUID = -3343461140846999383L;
	private String PLAN_ID;
	private String RH_ID;
	private String RTBL_ID;
	private String RH_BAND_AMT;
	private String RTBL_SEX_CD;
	private String DISCOUNT_OPTION;
	private String SMOKER_CODE;
	private String RTBL_MAT_XPRY_DUR;
	private String ISSUE_AGE;
	private String RTBL_AGE;
	private String RTBL_1_RT;
	public String getPLAN_ID() {
		return PLAN_ID;
	}
	public void setPLAN_ID(String pLAN_ID) {
		PLAN_ID = pLAN_ID;
	}
	public String getRH_ID() {
		return RH_ID;
	}
	public void setRH_ID(String rH_ID) {
		RH_ID = rH_ID;
	}
	public String getRTBL_ID() {
		return RTBL_ID;
	}
	public void setRTBL_ID(String rTBL_ID) {
		RTBL_ID = rTBL_ID;
	}
	public String getRH_BAND_AMT() {
		return RH_BAND_AMT;
	}
	public void setRH_BAND_AMT(String rH_BAND_AMT) {
		RH_BAND_AMT = rH_BAND_AMT;
	}
	public String getRTBL_SEX_CD() {
		return RTBL_SEX_CD;
	}
	public void setRTBL_SEX_CD(String rTBL_SEX_CD) {
		RTBL_SEX_CD = rTBL_SEX_CD;
	}
	public String getDISCOUNT_OPTION() {
		return DISCOUNT_OPTION;
	}
	public void setDISCOUNT_OPTION(String dISCOUNT_OPTION) {
		DISCOUNT_OPTION = dISCOUNT_OPTION;
	}
	public String getSMOKER_CODE() {
		return SMOKER_CODE;
	}
	public void setSMOKER_CODE(String sMOKER_CODE) {
		SMOKER_CODE = sMOKER_CODE;
	}
	public String getRTBL_MAT_XPRY_DUR() {
		return RTBL_MAT_XPRY_DUR;
	}
	public void setRTBL_MAT_XPRY_DUR(String rTBL_MAT_XPRY_DUR) {
		RTBL_MAT_XPRY_DUR = rTBL_MAT_XPRY_DUR;
	}
	public String getISSUE_AGE() {
		return ISSUE_AGE;
	}
	public void setISSUE_AGE(String iSSUE_AGE) {
		ISSUE_AGE = iSSUE_AGE;
	}
	public String getRTBL_AGE() {
		return RTBL_AGE;
	}
	public void setRTBL_AGE(String rTBL_AGE) {
		RTBL_AGE = rTBL_AGE;
	}
	public String getRTBL_1_RT() {
		return RTBL_1_RT;
	}
	public void setRTBL_1_RT(String rTBL_1_RT) {
		RTBL_1_RT = rTBL_1_RT;
	}
	@Override
	public String toString() {
		return "PlanDetailBean [PLAN_ID=" + PLAN_ID + ", RH_ID=" + RH_ID + ", RTBL_ID=" + RTBL_ID + ", RH_BAND_AMT="
				+ RH_BAND_AMT + ", RTBL_SEX_CD=" + RTBL_SEX_CD + ", DISCOUNT_OPTION=" + DISCOUNT_OPTION
				+ ", SMOKER_CODE=" + SMOKER_CODE + ", RTBL_MAT_XPRY_DUR=" + RTBL_MAT_XPRY_DUR + ", ISSUE_AGE="
				+ ISSUE_AGE + ", RTBL_AGE=" + RTBL_AGE + ", RTBL_1_RT=" + RTBL_1_RT + "]";
	}
}
