package com.qc.serviceimpl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.premiumcalc.ApiRequestpremiumCalc;
import com.qc.api.request.premiumcalc.ReqPlan;
import com.qc.api.request.premiumcalc.ReqRider;
import com.qc.api.response.MessageConstants;
import com.qc.api.response.premiumcalc.ApiResponsepremiumCalc;
import com.qc.api.response.premiumcalc.ResPayload;
import com.qc.api.response.premiumcalc.ResPlan;
import com.qc.api.response.premiumcalc.ResRider;
import com.qc.api.response.premiumcalc.ResponsepremiumCalc;
import com.qc.entity.PlanDetailBean;
import com.qc.service.NeoPremiumCalcService;
import com.qc.service.ObjectToPojoService;
import com.qc.service.PlanDetailService;
import com.qc.utils.PlanCodes;
import com.qc.utils.UniqueId;

/**
 * @author ad01084
 *
 */
@Service
@Transactional
public class PremiumCalculation implements NeoPremiumCalcService
{
	private static Logger logger = LogManager.getLogger(PremiumCalculation.class);
	@Autowired ObjectToPojoService objectToPojoService;
	@Autowired PlanDetailService planDetailService;
	@Autowired Environment env;
	@Autowired PlanCodes planCodes;

	@Override
	public ApiResponsepremiumCalc premiumCalculatorService(ApiRequestpremiumCalc premiumCalculatorRequest)
	{
		double riderPremium =0.0;
		double riderWGST =0.0;
		double totalvalueAdd =0.0;
		double totalvaluePlanAdd =0.0;
		double riderrate=0.0;
		double riderMode=0;
		double planBaseAnnualPremium;
		double planBasePremium;
		double gst;
		double planWGST;
		double TCCPABBaseAnnualPremium;
		double GSTRider;
		double wopSumAssured;
		double tccibBaseAnnualPremium;
		double totalPremiumWOGST;
		double totalPremiumWGST;
		double planWGSTTotal;
		double modeValue=0;
		double totalRiderPremium;
		double totalRiderWGST;
		double rate;
//		double totalplanBasePremium = 0;
//		double totalplanWGST =0.0;
		double totalriderWoGST = 0;

		String planId ="";
		String riderIdDCCCP ="";
		String riderIdVN05 ="";

		ResRider resRider =null;
		Header header=null;		
		ResPlan resPlan =null;
		MsgInfo msginfo = new MsgInfo();
		ResponsepremiumCalc response = new ResponsepremiumCalc();
		ApiResponsepremiumCalc apiResponse =new ApiResponsepremiumCalc();
		ResPayload payloadResGetDemoAuthRequest = new ResPayload();

		List<Map<String , String>> resultPlanDetailProc =null;
		List<PlanDetailBean> resultRiderDCCCP =null;
		List<PlanDetailBean> resultRiderVN05 =null;
		List<ResPlan> listResPlan = new ArrayList<ResPlan>();

		Map<String,Double> modelPremiumForVN05 = new HashMap<String,Double>();

		try
		{
			ThreadContext.push("getPremiumCalculation : " + UniqueId.getUniqueId());

			logger.debug("Request Header fields validation : Start");
			if(premiumCalculatorRequest != null 
					&& premiumCalculatorRequest.getRequest()!=null
					&& premiumCalculatorRequest.getRequest().getHeader() !=null
					&& premiumCalculatorRequest.getRequest().getHeader().getSoaAppId() !=null
					&& premiumCalculatorRequest.getRequest().getHeader().getSoaCorrelationId() !=null)
			{
				logger.debug("Request Header fields validation : Success");
				ThreadContext.push(premiumCalculatorRequest.getRequest().getHeader().getSoaCorrelationId());
				logger.info("premiumCalculatorService service : Start");
				planCodes.initialize();
				header=premiumCalculatorRequest.getRequest().getHeader();

				logger.debug("Request Payload fields validation : Start");
				if (premiumCalculatorRequest.getRequest().getPayload() != null
						&& premiumCalculatorRequest.getRequest().getPayload().getReqPlan()!= null 
						&& premiumCalculatorRequest.getRequest().getPayload().getReqPlan().size() >0)
				{
					logger.debug("Request Payload fields validation : Success");
					for(ReqPlan reqPlan:premiumCalculatorRequest.getRequest().getPayload().getReqPlan())
					{
						logger.info("plan value :: " +reqPlan.toString());
						modeValue=0;
						if(planCodes.getPlanIdforDB().contains(reqPlan.getPlanId()))
						{
							if(reqPlan.getPlanId()!=null && planCodes.getPlancodelistTCOT60TNOT60().contains(reqPlan.getPlanId().trim()))
							{
								planId +=planCodes.getPlan_tcot60();
							}
							else if(reqPlan.getPlanId()!=null && planCodes.getPlancodelistTCOTP2TNOTP2().contains(reqPlan.getPlanId().trim()))
							{
								planId +="TCOTP2";
							}

							if(reqPlan.getReqRider() !=null && reqPlan.getReqRider().size()>0)
							{
								for(int i=0 ;i<reqPlan.getReqRider().size();i++)
								{
									if(planCodes.getPlanIdforDB().contains(reqPlan.getReqRider().get(i).getRiderId()))
									{
										if(reqPlan.getReqRider().get(i).getRiderId()!=null && planCodes.getPlancodelistTCCIBTNCIB().contains(reqPlan.getReqRider().get(i).getRiderId().trim()))
										{
											planId +=","+"TCCIB";
										}
									}
									else if(planCodes.getRiderIdforDB().contains(reqPlan.getReqRider().get(i).getRiderId()))
									{
										if(reqPlan.getReqRider().get(i).getRiderId()!=null && planCodes.getPlancodelistDCCCP().contains(reqPlan.getReqRider().get(i).getRiderId().trim()))
										{
											riderIdDCCCP ="DCCCP";
										}
										else if(reqPlan.getReqRider().get(i).getRiderId() !=null && planCodes.getPlancodelistVN05VN04().contains(reqPlan.getReqRider().get(i).getRiderId().trim()))
										{
											riderIdVN05="VN05";
										}

									}
								}
							}
						}
						logger.info("plan id's value for database::" +planId);
						resultPlanDetailProc = planDetailService.callPremiumCalc(planId,reqPlan.getAge()!=null?reqPlan.getAge().trim():"",reqPlan.getGender()!=null?reqPlan.getGender():"",reqPlan.getEmpDiscount().equalsIgnoreCase("Y")?"Y":"No","premiumCalc");
						if(!riderIdDCCCP.equalsIgnoreCase(""))
						{
							resultRiderDCCCP=planDetailService.callPlanDetailService(riderIdDCCCP,reqPlan.getAge()!=null?reqPlan.getAge().trim():"",reqPlan.getGender()!=null?reqPlan.getGender():"");
							logger.info("plan id DCCCP value from database::" +resultRiderDCCCP);
						}
						if(!riderIdVN05.equalsIgnoreCase(""))
						{
							resultRiderVN05=planDetailService.callPlanDetailService(riderIdVN05,reqPlan.getAge()!=null?reqPlan.getAge().trim():"",reqPlan.getGender()!=null?reqPlan.getGender():"");
							logger.info("plan id VN05 value from database::" +resultRiderVN05);
						}
						if((resultPlanDetailProc!=null && resultPlanDetailProc.size()>0) )

						{
							if(!riderIdVN05.equalsIgnoreCase("") )
							{
								if(!(resultRiderVN05.size()>0) )
								{
									msginfo.setMsgCode(MessageConstants.C700);
									msginfo.setMsg(MessageConstants.FAILURE);
									msginfo.setMsgDescription(MessageConstants.C700DESC);
									logger.info(MessageConstants.C700DESC);
									logger.info("DATA not found from back end for ::" +riderIdVN05+","+reqPlan.getAge()!=null?reqPlan.getAge().trim():""+","+reqPlan.getGender()!=null?reqPlan.getGender():""+","+(reqPlan.getEmpDiscount().equalsIgnoreCase("Y")?"Yes":""));
									break;
								}
							}

							if( !riderIdDCCCP.equalsIgnoreCase(""))
							{
								if( !(resultRiderDCCCP.size()>0))
								{
									msginfo.setMsgCode(MessageConstants.C700);
									msginfo.setMsg(MessageConstants.FAILURE);
									msginfo.setMsgDescription(MessageConstants.C700DESC);
									logger.info(MessageConstants.C700DESC);
									logger.info("DATA not found from back end for ::" +riderIdDCCCP+","+reqPlan.getAge()!=null?reqPlan.getAge().trim():""+","+reqPlan.getGender()!=null?reqPlan.getGender():""+","+(reqPlan.getEmpDiscount().equalsIgnoreCase("Y")?"Yes":""));
									break;
								}
							}
							logger.info("value from backend value ::" +resultPlanDetailProc.toString());
							totalRiderPremium = 0.0;
							totalRiderWGST =0.0;
							List<ResRider> listResRider = new ArrayList<ResRider>();
							resPlan =new ResPlan();
							resPlan.setPlanId(reqPlan.getPlanId());
							resPlan.setVariantId(reqPlan.getVariantId());
							resPlan.setGender(reqPlan.getGender());
							resPlan.setAge(reqPlan.getAge());
							resPlan.setEmpDiscount(reqPlan.getEmpDiscount());
							resPlan.setPlanSumAssured(reqPlan.getPlanSumAssured());
							resPlan.setPolicyTerm(reqPlan.getPolicyTerm());
							resPlan.setPolicyPayTerm(reqPlan.getPolicyPayTerm());
							resPlan.setSmoke(reqPlan.getSmoke());
							resPlan.setMode(reqPlan.getMode());

							// for rate we check annual premium and policyTerm and varientId and smoker and non smoker and take rate for varient
							rate=0.0;
							if(reqPlan.getPlanId()!=null && !reqPlan.getPlanId().equalsIgnoreCase(""))
							{
								String ammount="";
								long premiumAmount=reqPlan.getPlanSumAssured()!=null?Long.valueOf(reqPlan.getPlanSumAssured().trim()):0;

								if(premiumAmount >= 0 && premiumAmount <= 4999999)
								{										  
									ammount="4999999";
								}
								else if(premiumAmount >= 5000000 && premiumAmount <= 9999999)
								{
									ammount="9999999";
								}
								else if(premiumAmount >= 10000000 && premiumAmount <= 49999999)
								{
									ammount="49999999";
								}
								else if(premiumAmount >= 50000000 && premiumAmount <= 9999999999999L)
								{
									ammount="9999999999999";
								}
								logger.info("premium amount for search in database values ::" +ammount);
								if(reqPlan.getPlanId() !=null && planCodes.getPlancodelistTCOTP2TNOTP2().contains(reqPlan.getPlanId().trim()))
								{
									logger.info("plan Id for TCOTP2 start");
									rate = rateCountForTCOTP2(resultPlanDetailProc,reqPlan,ammount);
									logger.info("rate value is :: " +rate);
									modeValue=modeCount(reqPlan);
									logger.info("modeValue  is :: " +modeValue);
								}
								else if(reqPlan.getPlanId() !=null && planCodes.getPlancodelistTCOT60TNOT60().contains(reqPlan.getPlanId().trim()))
								{
									logger.info("plan Id for TCOT60 start");
									rate = rateCountForTCOT60(resultPlanDetailProc,reqPlan,ammount);
									logger.info("rate value is :: " +rate);
									modeValue=modeCount(reqPlan);
									logger.info("modeValue  is :: " +modeValue);
								}
							}
							//multiply by one because it take annual premium
							planBaseAnnualPremium = (Double.valueOf(reqPlan.getPlanSumAssured().trim()) * rate * 1 )/1000;
							modelPremiumForVN05.put("PLANPremium", planBaseAnnualPremium);
							planBasePremium =(modeCountValue((Double.valueOf(reqPlan.getPlanSumAssured().trim()) * rate * modeValue )/1000,reqPlan.getMode()));
							logger.info("planBasePremium is ::" +planBasePremium);
							BigDecimal valuePlanPremiumTCCPAB= BigDecimal.valueOf(planBasePremium);
							/*BigDecimal valuePlanPremiumTCCPAB=new BigDecimal(planBasePremium);*/
							valuePlanPremiumTCCPAB = valuePlanPremiumTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
							resPlan.setPlanBasePremium(valuePlanPremiumTCCPAB.toString());
							gst = ((planBasePremium * 18)/100) ;
							logger.info("plan GST is ::" +gst);
							/*BigDecimal valuePlanGSTTCCPAB=new BigDecimal(GST);*/
							BigDecimal valuePlanGSTTCCPAB= BigDecimal.valueOf(gst);
							valuePlanGSTTCCPAB = valuePlanGSTTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
							/*BigDecimal valuePlan=new BigDecimal(planBasePremium + GST);*/
							BigDecimal valuePlan= BigDecimal.valueOf(planBasePremium + gst);
							totalvaluePlanAdd =valuePlan.doubleValue();
							valuePlan = valuePlan.setScale(0, BigDecimal.ROUND_HALF_UP);
							planWGST=valuePlan.doubleValue();
							//double planWGST = Math.floor(planBasePremium + GST);
							logger.info("planWGST is ::" +planWGST);
							resPlan.setPlanWGST(Double.toString(planWGST));
							resPlan.setPlanGST(valuePlanGSTTCCPAB.toString());
//							totalplanBasePremium += planBasePremium;
//							totalplanWGST +=planWGST;
							if(reqPlan.getReqRider() !=null && reqPlan.getReqRider().size()>0)
							{
								for(ReqRider reqRider : reqPlan.getReqRider())
								{
									riderrate=0.0;
									riderMode=0;
									if(reqRider.getRiderId()!=null && planCodes.getPlancodelistTCCIBTNCIB().contains(reqRider.getRiderId().trim()))
									{
										logger.info("plan Id for TCCIB start");
										riderrate=rateCountForRiderTCCIB(resultPlanDetailProc,reqRider);
										logger.info("Rider rate ::" +riderrate);
										riderMode=modeCountRider(reqPlan,reqRider.getRiderId().trim());
										logger.info("riderMode rate ::" +riderMode);
									}

									else if(reqRider.getRiderId()!=null && planCodes.getPlancodelistDCCCP().contains(reqRider.getRiderId().trim())){
										logger.info("plan Id for DCCCP start");
										String discount=reqPlan.getEmpDiscount().equalsIgnoreCase("Y")?"ED":"";
										riderrate=rateCountForRiderDCCCP(resultRiderDCCCP,reqRider,discount);
										logger.info("Rider rate ::" +riderrate);
										riderMode=modeCountRider(reqPlan,reqRider.getRiderId().trim());
										logger.info("riderMode rate ::" +riderMode);
									}
									else if(reqRider.getRiderId()!=null && planCodes.getPlancodelistTCCPABTNCPAB().contains(reqRider.getRiderId().trim()))
									{
										logger.info("plan Id for TCCPAB start");
										//	Riderrate=rateCountForRiderTCCPAB(result,reqRider);
										//	logger.info("Rider rate ::" +Riderrate);
										resRider = new ResRider();
										riderMode=modeCountRider(reqPlan,reqRider.getRiderId().trim());
										logger.info("riderMode rate ::" +riderMode);
										resRider.setRiderId(reqRider.getRiderId().trim());
										resRider.setRiderSA(reqRider.getRiderSA().trim());
										resRider.setRiderTerm(reqRider.getRiderTerm().trim());
										//multiply by one because it take annual premium
										TCCPABBaseAnnualPremium = (Double.valueOf(reqRider.getRiderSA().trim()) * 0.63 * 1)/1000;
										modelPremiumForVN05.put(reqRider.getRiderId().trim(), TCCPABBaseAnnualPremium);
										riderPremium =(modeCountValue((Double.valueOf(reqRider.getRiderSA().trim()) * 0.63 * riderMode)/1000,reqPlan.getMode()));
										logger.info("riderPremium is ::" +riderPremium);
										/*BigDecimal valueriderPremiumTCCPAB=new BigDecimal(riderPremium);*/
										BigDecimal valueriderPremiumTCCPAB= BigDecimal.valueOf(riderPremium);
										valueriderPremiumTCCPAB = valueriderPremiumTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
										totalriderWoGST=valueriderPremiumTCCPAB.doubleValue();
										resRider.setRiderPremium(valueriderPremiumTCCPAB.toString());
										GSTRider = ((riderPremium * 18)/100 );
										logger.info("riderWGST GST is ::" +GSTRider);
										/*	BigDecimal valueriderGSTTCCPAB=new BigDecimal(GSTRider);*/
										BigDecimal valueriderGSTTCCPAB= BigDecimal.valueOf(GSTRider);
										valueriderGSTTCCPAB = valueriderGSTTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
										resRider.setRiderGST(valueriderGSTTCCPAB.toString());
										/*BigDecimal valuerider=new BigDecimal(riderPremium + GSTRider);*/
										BigDecimal valuerider= BigDecimal.valueOf(riderPremium + GSTRider);
										totalvalueAdd = valuerider.doubleValue();
										valuerider = valuerider.setScale(0, BigDecimal.ROUND_HALF_UP);
										//riderWGST = Math.floor(riderPremium + GSTRider);
										riderWGST = valuerider.doubleValue();
										logger.info("riderWGST is ::" +riderWGST);
										resRider.setRiderWGST(Double.toString(riderWGST));
									}
									else if(reqRider.getRiderId()!=null && planCodes.getPlancodelistVN05VN04().contains(reqRider.getRiderId().trim())){
										logger.info("plan Id for VN05 start");
										resRider = new ResRider();
										resRider.setRiderId(reqRider.getRiderId().trim());
										//resRider.setRiderSA(reqRider.getRiderSA().trim());
										resRider.setRiderTerm(reqRider.getRiderTerm().trim());

										riderMode=modeCountRider(reqPlan,reqRider.getRiderId().trim());
										logger.info("riderMode rate ::" +riderMode);

										double wopsumdata =0.0;
										for (Map.Entry<String,Double> entry : modelPremiumForVN05.entrySet()) 
										{	
											wopsumdata +=entry.getValue();
										}
										wopSumAssured =wopsumdata*riderMode;
										//										double wopSumAssured =( (modelPremiumForVN05.get("PLANPremium")!=null ?modelPremiumForVN05.get("PLANPremium"):0.0 )+( modelPremiumForVN05.get("TCCIB")!=null ?modelPremiumForVN05.get("TCCIB"):0.0 )+( modelPremiumForVN05.get("TCCPAB")!=null ?modelPremiumForVN05.get("TCCPAB"):0.0))*riderMode;
										wopSumAssured = wopSumAssured >= 350000 ? 350000 :wopSumAssured;
										/*BigDecimal valueridersumAssured=new BigDecimal(wopSumAssured);*/
										BigDecimal valueridersumAssured= BigDecimal.valueOf(wopSumAssured);
										valueridersumAssured = valueridersumAssured.setScale(2, BigDecimal.ROUND_HALF_UP);
										resRider.setRiderSA(valueridersumAssured.toString());
										riderrate=rateCountForRiderVN05(resultRiderVN05,reqRider,wopSumAssured);
										logger.info("Rider rate ::" +riderrate);

										riderPremium =(modeCountValue((wopSumAssured * riderrate )/1000,reqPlan.getMode()));
										logger.info("riderPremium is ::" +riderPremium);
										/*BigDecimal valueriderPremiumTCCPAB=new BigDecimal(riderPremium);*/
										BigDecimal valueriderPremiumTCCPAB= BigDecimal.valueOf(riderPremium);
										valueriderPremiumTCCPAB = valueriderPremiumTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
										totalriderWoGST=valueriderPremiumTCCPAB.doubleValue();
										resRider.setRiderPremium(valueriderPremiumTCCPAB.toString());
										GSTRider = ((riderPremium * 18)/100 );
										logger.info("riderWGST GST is ::" +GSTRider);
										/*BigDecimal valueriderGSTTCCPAB=new BigDecimal(GSTRider);*/
										BigDecimal valueriderGSTTCCPAB= BigDecimal.valueOf(GSTRider);
										valueriderGSTTCCPAB = valueriderGSTTCCPAB.setScale(2, BigDecimal.ROUND_HALF_UP);
										resRider.setRiderGST(valueriderGSTTCCPAB.toString());
										/*BigDecimal valuerider=new BigDecimal(riderPremium + GSTRider);*/
										BigDecimal valuerider=BigDecimal.valueOf(riderPremium + GSTRider);
										totalvalueAdd = valuerider.doubleValue();
										valuerider = valuerider.setScale(0, BigDecimal.ROUND_HALF_UP);
										//riderWGST = Math.floor(riderPremium + GSTRider);
										riderWGST = valuerider.doubleValue();
										logger.info("riderWGST is ::" +riderWGST);
										resRider.setRiderWGST(Double.toString(riderWGST));
									}

									if(reqRider!=null 
											&& (planCodes.getPlancodelistTCCIBTNCIB().contains(reqRider.getRiderId().trim()) 
													|| planCodes.getPlancodelistDCCCP().contains(reqRider.getRiderId().trim())
													)
											)
									{
										resRider = new ResRider();
										resRider.setRiderId(reqRider.getRiderId().trim());
										resRider.setRiderSA(reqRider.getRiderSA().trim());
										resRider.setRiderTerm(reqRider.getRiderTerm().trim());

										if(planCodes.getPlancodelistTCCIBTNCIB().contains(reqRider.getRiderId().trim()))
										{
											//multiply by one because it take annual premium
											tccibBaseAnnualPremium = (Double.valueOf(reqRider.getRiderSA().trim()) * riderrate * 1)/1000;
											modelPremiumForVN05.put(reqRider.getRiderId(), tccibBaseAnnualPremium);
											riderPremium =(modeCountValue((Double.valueOf(reqRider.getRiderSA()!=""?reqRider.getRiderSA():"0.0") * riderrate * riderMode)/1000,reqPlan.getMode()));
										}
										if(planCodes.getPlancodelistDCCCP().contains(reqRider.getRiderId().trim()))
										{
											riderPremium =((Double.valueOf(reqRider.getRiderSA()!=""?reqRider.getRiderSA():"0.0") * riderrate * riderMode)/1000);
										}
										//										riderPremium =(modeCountValue((Double.valueOf(reqRider.getRiderSA()!=""?reqRider.getRiderSA():"0.0") * Riderrate * riderMode)/1000,reqPlan.getMode()));
										/*	BigDecimal valueriderPremium=new BigDecimal(riderPremium);*/
										BigDecimal valueriderPremium=BigDecimal.valueOf(riderPremium);
										valueriderPremium = valueriderPremium.setScale(2, BigDecimal.ROUND_HALF_UP);
										logger.info("riderPremium is ::" +riderPremium);
										totalriderWoGST=valueriderPremium.doubleValue();
										resRider.setRiderPremium((valueriderPremium.toString()));
										GSTRider = ((riderPremium * 18)/100 );
										logger.info("riderWGST GST is ::" +GSTRider);
										/*BigDecimal valueriderGST=new BigDecimal(GSTRider);*/
										BigDecimal valueriderGST=BigDecimal.valueOf(GSTRider);
										valueriderGST = valueriderGST.setScale(2, BigDecimal.ROUND_HALF_UP);
										resRider.setRiderGST(valueriderGST.toString());
										/*BigDecimal valueriderOther=new BigDecimal(riderPremium + GSTRider);*/
										BigDecimal valueriderOther= BigDecimal.valueOf(riderPremium + GSTRider);
										totalvalueAdd = valueriderOther.doubleValue();
										valueriderOther = valueriderOther.setScale(0, BigDecimal.ROUND_HALF_UP);
										riderWGST=valueriderOther.doubleValue();
										// riderWGST = Math.floor(riderPremium + GSTRider);
										logger.info("riderWGST is ::" +riderWGST);
										resRider.setRiderWGST(Double.toString(riderWGST));
									}
									if(resRider.getRiderId().equalsIgnoreCase(reqRider.getRiderId()))
									{
										listResRider.add(resRider);
										totalRiderPremium += totalriderWoGST;
										//										totalRiderWGST +=riderWGST;
										totalRiderWGST +=totalvalueAdd;
									}
									else
									{
										resRider = new ResRider();
										resRider.setRiderId(reqRider.getRiderId().trim());
										resRider.setRiderSA(reqRider.getRiderSA().trim());
										resRider.setRiderTerm(reqRider.getRiderTerm().trim());
										listResRider.add(resRider);
									}
								}
							}
							/*BigDecimal totalRiderPremium2Scale=new BigDecimal(totalRiderPremium);*/
							BigDecimal totalRiderPremium2Scale= BigDecimal.valueOf(totalRiderPremium);
							totalRiderPremium2Scale = totalRiderPremium2Scale.setScale(2, BigDecimal.ROUND_HALF_UP);
							resPlan.setTotalRiderPremiumWOGST((totalRiderPremium2Scale).toString());
							logger.info("totalRiderPremiumWOGST is ::" +totalRiderPremium);
							/*BigDecimal totalRiderWGST2Scale=new BigDecimal(totalRiderWGST);*/
							BigDecimal totalRiderWGST2Scale= BigDecimal.valueOf(totalRiderWGST);
							totalRiderWGST2Scale = totalRiderWGST2Scale.setScale(2, BigDecimal.ROUND_HALF_UP);
							resPlan.setTotalRiderPremiumWGST((totalRiderWGST2Scale).toString());
							logger.info("setTotalRiderPremiumWGST is ::" +totalRiderWGST);
							totalPremiumWOGST =totalRiderPremium+planBasePremium;
							logger.info("totalPremiumWOGST is ::" +totalPremiumWOGST);
							totalPremiumWGST =totalRiderWGST+totalvaluePlanAdd;
							//							double totalPremiumWGST =totalRiderWGST+planWGST;
							logger.info("totalPremiumWGST is ::" +totalPremiumWGST);
							/*BigDecimal totalPremiumWGST2Scale=new BigDecimal(totalPremiumWGST);*/
							BigDecimal totalPremiumWGST2Scale=BigDecimal.valueOf(totalPremiumWGST);
							totalPremiumWGST2Scale = totalPremiumWGST2Scale.setScale(0, BigDecimal.ROUND_HALF_UP);
							planWGSTTotal=totalPremiumWGST2Scale.doubleValue();
							resPlan.setTotalPremiumWGST(Double.toString(planWGSTTotal));
							logger.info("setTotalPremiumWGST is ::" +totalPremiumWGST);
							/*						BigDecimal totalPremiumWOGST2Scale=new BigDecimal(totalPremiumWOGST);*/
							BigDecimal totalPremiumWOGST2Scale= BigDecimal.valueOf(totalPremiumWOGST);
							totalPremiumWOGST2Scale = totalPremiumWOGST2Scale.setScale(2, BigDecimal.ROUND_HALF_UP);
							resPlan.setTotalPremiumWOGST((totalPremiumWOGST2Scale).toString());
							logger.info("setTotalPremiumWOGST is ::" +totalPremiumWOGST);
							resPlan.setResRider(listResRider);
							listResPlan.add(resPlan);
						}
						else
						{
							msginfo.setMsgCode(MessageConstants.C700);
							msginfo.setMsg(MessageConstants.FAILURE);
							msginfo.setMsgDescription(MessageConstants.C700DESC);
							logger.info(MessageConstants.C700DESC);
							logger.info("DATA not found from back end for ::" +planId+","+reqPlan.getAge()!=null?reqPlan.getAge().trim():""+","+reqPlan.getGender()!=null?reqPlan.getGender():""+","+(reqPlan.getEmpDiscount().equalsIgnoreCase("Y")?"Yes":"No"));
						}
					}
					if(listResPlan != null && listResPlan.size() > 0)
					{
						payloadResGetDemoAuthRequest.setResPlan(listResPlan);
						response.setPayload(payloadResGetDemoAuthRequest);
						msginfo.setMsgCode(MessageConstants.C200);
						msginfo.setMsg(MessageConstants.SUCCESS);
						msginfo.setMsgDescription(MessageConstants.C200DESC);
						logger.info(MessageConstants.C200DESC);
					}
					else if(msginfo.getMsgCode() ==null || msginfo.getMsgCode().equalsIgnoreCase(""))
					{
						msginfo.setMsgCode(MessageConstants.C500);
						msginfo.setMsg(MessageConstants.FAILURE);
						msginfo.setMsgDescription(MessageConstants.C605DESC);
						logger.info(MessageConstants.C500DESC);
					}
				}
				else
				{
					msginfo.setMsgCode(MessageConstants.C600);
					msginfo.setMsg(MessageConstants.FAILURE);
					msginfo.setMsgDescription(MessageConstants.C600DESC);
					logger.info(MessageConstants.C600DESC);
					apiResponse = new ApiResponsepremiumCalc(new ResponsepremiumCalc(header, msginfo, null));
				}
			}
			else
			{
				msginfo.setMsgCode(MessageConstants.C600);
				msginfo.setMsg(MessageConstants.FAILURE);
				msginfo.setMsgDescription(MessageConstants.C600HDESC);
				logger.info(MessageConstants.C600HDESC);
				apiResponse = new ApiResponsepremiumCalc(new ResponsepremiumCalc(header, msginfo, null));
			}
		} 
		catch (Exception e) 
		{
			msginfo.setMsgCode(MessageConstants.C500);
			msginfo.setMsg(MessageConstants.FAILURE);
			msginfo.setMsgDescription(MessageConstants.C500DESC);
			logger.error(MessageConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: maxservice::NeoControllerRest:: getPremiumCalculation : "+MessageConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponsepremiumCalc(new ResponsepremiumCalc(header, msginfo, null));
		}

		response.setHeader(header);
		response.setMsgInfo(msginfo);
		apiResponse.setResponse(response);

		try 
		{
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("ResponseJson :: "+ow.writeValueAsString(apiResponse));
		}
		catch (Exception ex) 
		{
			logger.error("Error While converting response data to json : "+ex);
		}
		finally 
		{
			logger.info("premiumCalculatorService  service : End");
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return apiResponse;
	}

	public double rateCountForTCOT60(List<Map<String , String>> result,ReqPlan reqPlan,String ammount){

		logger.info("premiumCalculatorService :: rateCountForTCOT60 :: service : Start");
		double rate =0.0;
		try
		{
			for(Map<String , String> resultData :result)
			{
				//				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase(reqPlan.getPlanId())
				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase("TCOT60")
						&& resultData.get("key3")!=null && resultData.get("key3").trim().equalsIgnoreCase(ammount)
						&& resultData.get("key7")!=null && resultData.get("key7").trim().equalsIgnoreCase(reqPlan.getPolicyTerm())
						&& resultData.get("key6")!=null && resultData.get("key6").trim().equalsIgnoreCase(reqPlan.getSmoke().trim().equalsIgnoreCase("Y")?"S":"N"))
				{
					if(resultData.get("key10")!=null && resultData.get("key10").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key11") ==null?0.0:Double.valueOf(resultData.get("key11").trim());
						break;
					}
					else if(resultData.get("key12")!=null && resultData.get("key12").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key13") == null?0.0:Double.valueOf(resultData.get("key13").trim());
						break;
					}
					else if(resultData.get("key14")!=null && resultData.get("key14").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key15") == null?0.0:Double.valueOf(resultData.get("key15").trim());
						break;
					}
				}
			}
		}
		catch(Exception e){
			logger.error("some error occurs in rateCountForTCOT60 ::" +e );
		}
		logger.info("rate value is ::" +rate);
		logger.info("premiumCalculatorService :: rateCountForTCOT60::service : End");
		return rate;

	}

	public double rateCountForTCOTP2(List<Map<String , String>> result,ReqPlan reqPlan,String ammount){

		logger.info("premiumCalculatorService :: rateCountForTCOTP2 :: service : Start");
		double rate =0.0;
		try
		{
			for(Map<String , String> resultData :result)
			{
				//				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase(reqPlan.getPlanId())
				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase("TCOTP2")
						&& resultData.get("key3")!=null && resultData.get("key3").trim().equalsIgnoreCase(ammount)
						&& resultData.get("key7")!=null && resultData.get("key7").trim().equalsIgnoreCase(reqPlan.getPolicyTerm())
						&& resultData.get("key6")!=null && resultData.get("key6").trim().equalsIgnoreCase(reqPlan.getSmoke().trim().equalsIgnoreCase("Y")?"S":"N"))
				{
					if(resultData.get("key10")!=null && resultData.get("key10").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key11") == null?0.0:Double.valueOf(resultData.get("key11").trim());
						break;
					}
					else if(resultData.get("key12")!=null && resultData.get("key12").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key13") == null?0.0:Double.valueOf(resultData.get("key13").trim());
						break;
					}
					else if(resultData.get("key14")!=null && resultData.get("key14").trim().equalsIgnoreCase(reqPlan.getVariantId()))
					{
						rate = resultData.get("key15") == null?0.0:Double.valueOf(resultData.get("key15").trim());
						break;
					}
				}
			}
		}

		catch(Exception e){
			logger.error("some error occurs in rateCountForTCOTP2 ::" +e );
		}
		logger.info("rate value is ::" +rate);
		logger.info("premiumCalculatorService :: rateCountForTCOTP2 service : End");
		return rate;

	}

	public double rateCountForRiderVN05(List<PlanDetailBean> result,ReqRider reqRider,double amount){

		logger.info("premiumCalculatorService :: rateCountForRiderVN05 :: service : Start");
		double Riderrate =0.0;
		String ammountRider="";
		try
		{
			double premiumAmountRider = Double.compare(amount, 0.0D) != 0?amount:0D;
			if(premiumAmountRider >= 0 && premiumAmountRider <= 9999999999999L)
			{										  
				ammountRider="9999999999999";
			}

			for(PlanDetailBean resultData :result)
			{
				if(resultData.getRH_BAND_AMT()!=null && resultData.getRH_BAND_AMT().equalsIgnoreCase(ammountRider)
						&& resultData.getRTBL_MAT_XPRY_DUR() !=null && resultData.getRTBL_MAT_XPRY_DUR().equalsIgnoreCase(reqRider.getRiderTerm()))
				{
					Riderrate = resultData.getRTBL_1_RT() ==null ?0.0:Double.valueOf(resultData.getRTBL_1_RT());
					break;
				}
			}
		}
		catch(Exception e){
			logger.error("some error occurs in rateCountForRiderVN05 ::" +e );
		}
		logger.info("rate value is ::" +Riderrate);
		logger.info("premiumCalculatorService :: rateCountForRiderVN05 service : End");
		return Riderrate;

	}

	public double rateCountForRiderTCCIB(List<Map<String , String>> result,ReqRider reqRider){

		logger.info("premiumCalculatorService :: rateCountForRiderTCCIB :: service : Start");
		double Riderrate =0.0;
		String ammountRider="";
		try
		{
			long premiumAmountRider=reqRider.getRiderSA()!=null?Long.valueOf(reqRider.getRiderSA().trim()):0;
			if(premiumAmountRider >= 0 && premiumAmountRider <= 1499999)
			{										  
				ammountRider="1499999";
			}
			else if(premiumAmountRider >= 1500000 && premiumAmountRider <= 9999999999L)
			{
				ammountRider="9999999999";
			}

			for(Map<String , String> resultData :result)
			{
				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase("TCCIB")
						&& resultData.get("key3")!=null && resultData.get("key3").trim().equalsIgnoreCase(ammountRider)
						&& resultData.get("key7")!=null && resultData.get("key7").trim().equalsIgnoreCase(reqRider.getRiderTerm())
						)
				{
					Riderrate = resultData.get("key16") == null?0.0:Double.valueOf(resultData.get("key16").trim());
					break;
				}
			}
		}
		catch(Exception e){
			logger.error("some error occurs in rateCountForRiderTCCIB ::" +e );
		}
		logger.info("rate value is :: " +Riderrate);
		logger.info("premiumCalculatorService :: rateCountForRiderTCCIB service : End");
		return Riderrate;
	}

	public double rateCountForRiderTCCPAB(List<Map<String , String>> result,ReqRider reqRider){

		logger.info("premiumCalculatorService :: rateCountForRiderTCCPAB :: service : Start");
		double Riderrate =0.0;
		String ammountRider="";
		try
		{
			long premiumAmountRider=reqRider.getRiderSA()!=null?Long.valueOf(reqRider.getRiderSA().trim()):0;
			if(premiumAmountRider >= 0 && premiumAmountRider <= 9999999999999L)
			{										  
				ammountRider="9999999999999";
			}

			for(Map<String , String> resultData :result)
			{
				if(resultData.get("key0")!=null && resultData.get("key0").trim().equalsIgnoreCase(reqRider.getRiderId())
						&& resultData.get("key3")!=null && resultData.get("key3").trim().equalsIgnoreCase(ammountRider)
						&& resultData.get("key7")!=null && resultData.get("key7").trim().equalsIgnoreCase(reqRider.getRiderTerm())
						)
				{
					Riderrate = resultData.get("key16") == null?0.0:Double.valueOf(resultData.get("key16").trim());
					break;
				}
			}
		}
		catch(Exception e){
			logger.error("some error occurs in rateCountForRiderTCCPAB ::" +e );
		}
		logger.info("rate value is ::" +Riderrate);
		logger.info("premiumCalculatorService :: rateCountForRiderTCCPAB service : End");
		return Riderrate;

	}

	public double rateCountForRiderDCCCP(List<PlanDetailBean> result,ReqRider reqRider, String discount){

		logger.info("premiumCalculatorService :: rateCountForRiderTCCIB :: service : Start");
		double Riderrate =0.0;
		String ammountRider="";

		try
		{
			long premiumAmountRider=reqRider.getRiderSA()!=null?Long.valueOf(reqRider.getRiderSA().trim()):0;
			if(premiumAmountRider >= 0 && premiumAmountRider <= 1000000)
			{										  
				ammountRider="1000000";
			}
			else if(premiumAmountRider >= 1000001 && premiumAmountRider <= 1500000)
			{
				ammountRider="1500000";
			}
			else if(premiumAmountRider >= 1500001 && premiumAmountRider <= 2000000)
			{
				ammountRider="2000000";
			}
			else if(premiumAmountRider >= 2000001 && premiumAmountRider <= 2500000)
			{
				ammountRider="2500000";
			}
			else if(premiumAmountRider >= 2500001 && premiumAmountRider <= 3500000)
			{
				ammountRider="3500000";
			}
			else if(premiumAmountRider >= 3500001 && premiumAmountRider <= 5000000)
			{
				ammountRider="5000000";
			}

			for(PlanDetailBean resultData :result)
			{
				if(resultData.getRH_BAND_AMT()!=null && resultData.getRH_BAND_AMT().equalsIgnoreCase(ammountRider)
						&& resultData.getRTBL_MAT_XPRY_DUR() !=null && resultData.getRTBL_MAT_XPRY_DUR().equalsIgnoreCase(reqRider.getRiderTerm())
						&& resultData.getDISCOUNT_OPTION() !=null && resultData.getDISCOUNT_OPTION().equalsIgnoreCase(discount))
				{
					Riderrate = resultData.getRTBL_1_RT() ==null ?0.0:Double.valueOf(resultData.getRTBL_1_RT());
					break;
				}
			}
		}
		catch(Exception e){
			logger.error("some error occurs in rateCountForRiderTCCIB ::" +e );
		}
		logger.info("rate value is ::" +Riderrate);
		logger.info("premiumCalculatorService :: rateCountForRiderTCCIB service : End");
		return Riderrate;
	}

	public double modeCountRider(ReqPlan reqPlan,String reqRider)
	{
		logger.info("premiumCalculatorService :: modeCount :: service : Start");
		double modeRate =0.0;
		try
		{
			if(reqRider !=null &&( planCodes.getPlancodelistTCCIBTNCIB().contains(reqRider)))
			{
				switch(reqPlan.getMode().toUpperCase())
				{  
				case "ANNUAL": modeRate=1;break;  
				case "SEMI-ANNUAL": modeRate=1.026;break;  
				case "QUARTERLY":modeRate=1.044;break;  
				case "MONTHLY": modeRate=1.056;break; 
				} 
			}
			else if(reqRider!=null &&(planCodes.getPlancodelistTCCPABTNCPAB().contains(reqRider) || planCodes.getPlancodelistVN05VN04().contains(reqRider) ))
			{
				switch(reqPlan.getMode().toUpperCase())
				{  
				case "ANNUAL": modeRate=1;break;  
				case "SEMI-ANNUAL": modeRate=1.04;break;  
				case "QUARTERLY":modeRate=1.06;break;  
				case "MONTHLY": modeRate=1.08;break; 
				} 
			}
			else if(reqRider!=null &&(planCodes.getPlancodelistDCCCP().contains(reqRider)  ))
			{
				switch(reqPlan.getMode().toUpperCase())
				{  
				case "ANNUAL": modeRate=1;break;  
				case "SEMI-ANNUAL": modeRate=0.52;break;  
				case "QUARTERLY":modeRate=0.265;break;  
				case "MONTHLY": modeRate=0.09;break; 
				//	case "ANNUAL": modeRate=1;break;  
				//	case "SEMI-ANNUAL": modeRate=1.52;break;  
				//	case "QUARTERLY":modeRate=1.265;break;  
				//	case "MONTHLY": modeRate=1.09;break; 
				} 
			}
		}
		catch(Exception e){
			logger.error("some error occurs in modeCount ::" +e );
		}
		logger.info("rate value is ::" +modeRate);
		logger.info("premiumCalculatorService :: modeCount service : End");
		return modeRate;

	}

	public double modeCount(ReqPlan reqPlan)
	{
		logger.info("premiumCalculatorService :: modeCount :: service : Start");
		double modeRate =0.0;
		try
		{
			if(reqPlan.getPlanId()!=null 
					&& (planCodes.getPlancodelistTCOT60TNOT60().contains(reqPlan.getPlanId().trim())  
							|| planCodes.getPlancodelistTCOTP2TNOTP2().contains(reqPlan.getPlanId().trim()) 
							)
					)
			{
				switch(reqPlan.getMode().toUpperCase())
				{  
				case "ANNUAL": modeRate=1;break;  
				case "SEMI-ANNUAL": modeRate=1.026;break;  
				case "QUARTERLY":modeRate=1.044;break;  
				case "MONTHLY": modeRate=1.056;break; 
				}  
			}

		}
		catch(Exception e){
			logger.error("some error occurs in modeCount ::" +e );
		}
		logger.info("rate value is ::" +modeRate);
		logger.info("premiumCalculatorService :: modeCount service : End");
		return modeRate;

	}

	public double modeCountValue(Double value,String reqRider)
	{
		logger.info("premiumCalculatorService :: modeCountValue service : Start");
		double result=0.0;
		try
		{
			switch(reqRider.toUpperCase())
			{  
			case "ANNUAL": result=value/1;break;  
			case "SEMI-ANNUAL": result=value/2;break;  
			case "QUARTERLY":result=value/4;break;  
			case "MONTHLY": result=value/12;break; 
			}  
		}
		catch(Exception e)
		{
			logger.error("data devide by mode have some issue ::"+e  );
		}


		logger.info("premiumCalculatorService :: modeCountValue service : End");
		return result;

	}
}
