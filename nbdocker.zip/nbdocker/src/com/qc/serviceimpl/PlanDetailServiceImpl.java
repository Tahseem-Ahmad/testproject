package com.qc.serviceimpl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.dao.NeoDao;
import com.qc.entity.PlanDetailBean;
import com.qc.service.ObjectToPojoService;
import com.qc.service.PlanDetailService;

/**
 * @author ad01084
 *
 */
@Service
public class PlanDetailServiceImpl implements PlanDetailService 
{
	private static Logger logger = LogManager.getLogger(PlanDetailServiceImpl.class);
	@Autowired Environment env;
	@Autowired NeoDao neoDao;
	@Autowired DozerBeanMapper dozerBeanMapper;
	@Autowired ObjectToPojoService objectToPojoService;


	@Override
	@Cacheable(value="nbserviceCache", key="#planid.concat('-').concat(#rtbl_age_dur).concat('-').concat(#rtbl_sex)", unless="#result == null")
	public List<PlanDetailBean> callPlanDetailService(String planid,String rtbl_age_dur,String rtbl_sex)
	{
		logger.info("Going to Hit DB Plandetails: data not exist in cache");
		return neoDao.callPlanDetail(planid, rtbl_age_dur, rtbl_sex);
	}

	@Override
	@Cacheable(value="nbserviceCache", key="#plans.concat('-').concat(#rtblAgeDur).concat('-').concat(#rtblSex).concat('-').concat(#empDiscount).concat('-').concat(#serviceName)", unless="#result == null")
	public List<Map<String , String>> callPremiumCalc(String plans, String rtblAgeDur, String rtblSex, String empDiscount,String serviceName)

	{
		logger.info("Going to Hit DB callPremiumCalc: data not exist in cache");
		List<Map<String , String>> result = objectToPojoService.getCustomClass(neoDao.callPlanDetailsV2(plans,rtblAgeDur,rtblSex,empDiscount));
		logger.info("Size of proc list : "+result.size());
		if(result.size() > 0)
		{
			logger.info("Data  found from DataBase!");
		}
		else
		{
			logger.info("Data not found from DataBase!");
			return null;
		}
		return result;
	}
}
