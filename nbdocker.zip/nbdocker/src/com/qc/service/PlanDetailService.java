package com.qc.service;

import java.util.List;
import java.util.Map;

import com.qc.entity.PlanDetailBean;

public interface PlanDetailService 
{
	public List<PlanDetailBean> callPlanDetailService(String planid,String rtbl_age_dur,String rtbl_sex);

	public List<Map<String , String>> callPremiumCalc(String plans, String rtblAgeDur, String rtblSex, String empDiscount,String serviceName);
}
