package com.qc.service;

import com.qc.api.request.premiumcalc.ApiRequestpremiumCalc;
import com.qc.api.response.premiumcalc.ApiResponsepremiumCalc;

public interface NeoPremiumCalcService {

	public ApiResponsepremiumCalc premiumCalculatorService(ApiRequestpremiumCalc premiumCalculatorRequest);

}
