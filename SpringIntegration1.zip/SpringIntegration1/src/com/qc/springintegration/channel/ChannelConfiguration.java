package com.qc.springintegration.channel;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.PollableChannel;

@Configuration
@EnableIntegration
public class ChannelConfiguration {

	@Bean
	public MessageChannel requestChannel() {
		return new DirectChannel();
	}
	
	@Bean
	public MessageChannel outputChannel() {
		return new DirectChannel();
	}
	
	@Bean
	public MessageChannel replyChannel1() {
	   return new DirectChannel();
     }
	@Bean
	public MessageChannel requestChannel1() {
		return new DirectChannel();
	}
}
