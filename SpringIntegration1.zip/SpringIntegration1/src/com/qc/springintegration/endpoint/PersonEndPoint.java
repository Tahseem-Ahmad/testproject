package com.qc.springintegration.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.integration.support.MessageBuilder;

import com.qc.springintegration.msg.Person;

@Component
public class PersonEndPoint {

	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	@ServiceActivator(inputChannel="requestChannel1",requiresReply="true")
	public Message<Person> post(Message<Person> msg){
		System.out.println("In service activator "+msg.getPayload());
		return MessageBuilder.withPayload(msg.getPayload())
				.copyHeadersIfAbsent(msg.getHeaders())
				.setHeader("http_statusCode", HttpStatus.OK)
				
				.build();
	}
}
