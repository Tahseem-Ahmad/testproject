package com.qc.springintegration.endpoint;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.PollableChannel;
import org.springframework.stereotype.Component;

import com.qc.springintegration.msg.Book;
import com.qc.springintegration.msg.HelloMsg;

@Component
public class WelcomeEndpoint {
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	@Qualifier("reply.channel")
	PollableChannel replyChannel1;
	
	@Autowired
	MessageChannel requestChannel1;
	
	@ServiceActivator(inputChannel="requestChannel",outputChannel="outputChannel")
	public Message<?> get(Message<String> msg) {
        String name = msg.getPayload();
        // Log
        log.info("Request with name = " + name);
        
        // Get currentTime
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentTime = dtf.format(now);
        
        String strMsg = "Hello " +  name + "! " + "Welcome to Spring Integration with Spring Boot!";
        
        HelloMsg returnMsg = new HelloMsg(strMsg, currentTime);
        Book b=new Book();
		b.setId(2L);
		b.setBookName("Design Pattern");
		Message<Book> message=MessageBuilder.withPayload(b).setHeader("content-type","application/json").build();
		Boolean sendSuccess=requestChannel1.send(message);
		System.out.println("sendSuccess"+sendSuccess);
		
		Book result= (Book)replyChannel1.receive().getPayload();
		System.out.println("REPLY "+result.getUnId());
        
        return MessageBuilder.withPayload(result)
            .copyHeadersIfAbsent(msg.getHeaders())
            .setHeader("http_statusCode", HttpStatus.OK)
            .build();
    }
}