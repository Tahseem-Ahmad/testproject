package com.qc.springintegration.msg;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter(value=AccessLevel.PUBLIC)
@Setter(value=AccessLevel.PUBLIC)
@EqualsAndHashCode(of= {"bookName"})
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Book {
 String unId;	
 Long id;
 String bookName;
}
