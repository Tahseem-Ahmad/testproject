package com.mli.springmongointegration.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mli.springmongointegration.domain.Request;
import com.mli.springmongointegration.domain.RequestData;
import com.mli.springmongointegration.domain.User;
import com.mli.springmongointegration.repository.MliPolicyRepository;
import com.mli.springmongointegration.repository.UserRepository;
import com.mli.springmongointegration.service.MliPolicyService;


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    MliPolicyRepository policyRepository;
    
    @Autowired
    MliPolicyService mliPolicyService; 
    
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public User create(@RequestBody User user) {
    	    System.out.println(user);
        return userRepository.save(user);
    }

    @RequestMapping(value = "/{id}") 
    public User read(@PathVariable String id) {
        return userRepository.findOne(id);
        
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    public void update(@RequestBody User user) {
        userRepository.save(user);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE) 
    public void delete(@PathVariable String id) {
        userRepository.delete(id);
        
    }
    @RequestMapping(value ="/policy", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
    public void createPolicy(@RequestBody Request request) {
    	  //System.out.println(request);
    	  ObjectMapper mapper=new ObjectMapper();
    	  try {
			//Request request1 =mapper.readValue(request, Request.class);
			RequestData requestData =mliPolicyService.createOrUpdate(request.getRequestData());
			System.out.println(requestData);
			//System.out.println(request1);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  //RequestData requestData =policyRepository.save(request.getRequestData());
    }
}
