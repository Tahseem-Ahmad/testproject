package com.mli.springmongointegration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.Nominee;

public interface NomineeRepository extends MongoRepository<Nominee, String>{

}
