package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="APPOINTEE_DETAILS")
public class Appointee {
	@Id
	private String id;	
	private String name;
	private String status;
	private String relationship;
	private String dob;
	private String percentageShare;
	private String mobileNumber;
	private String clientId;
	private String address;
	private String gender;
	private String smoker;
	private String planName;
	private String policyTerm;
	private String premiumPolicyTerm;
	private String premium;
	private String sumAssured;
	private String paymentMode;
	
	private String policyNumber;

	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPaymentMode() {
		return paymentMode;
	}
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPremiumPolicyTerm() {
		return premiumPolicyTerm;
	}
	public void setPremiumPolicyTerm(String premiumPolicyTerm) {
		this.premiumPolicyTerm = premiumPolicyTerm;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getSmoker() {
		return smoker;
	}
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPercentageShare() {
		return percentageShare;
	}
	public void setPercentageShare(String percentageShare) {
		this.percentageShare = percentageShare;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Appointee [id=" + id + ", name=" + name + ", status=" + status + ", relationship=" + relationship
				+ ", dob=" + dob + ", percentageShare=" + percentageShare + ", address=" + address + "]";
	}

}
