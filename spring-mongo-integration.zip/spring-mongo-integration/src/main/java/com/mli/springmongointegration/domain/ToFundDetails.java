package com.mli.springmongointegration.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ToFundDetails {
	 private String toAmount;
	 
	 private String toFundName;

	 private String toAmountPercentage;

	public String getToAmount() {
		return toAmount;
	}

	public void setToAmount(String toAmount) {
		this.toAmount = toAmount;
	}

	public String getToFundName() {
		return toFundName;
	}

	public void setToFundName(String toFundName) {
		this.toFundName = toFundName;
	}

	public String getToAmountPercentage() {
		return toAmountPercentage;
	}

	public void setToAmountPercentage(String toAmountPercentage) {
		this.toAmountPercentage = toAmountPercentage;
	}

	@Override
	public String toString() {
		return "ToFundDetails [toAmount=" + toAmount + ", toFundName=" + toFundName + ", toAmountPercentage="
				+ toAmountPercentage + "]";
	}
	 
	 
}
