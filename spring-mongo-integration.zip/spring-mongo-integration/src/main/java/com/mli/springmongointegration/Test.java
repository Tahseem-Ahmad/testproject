package com.mli.springmongointegration;

public class Test {

	public static void main(String[] args) 
	{
		System.out.println(incomeCalculator(""));

	}
	private static String incomeCalculator(String income)
	{
		
		Integer incomeData = Integer.parseInt(income.isEmpty()?"0":income);
		if(incomeData<=500000)
		{
			return "<5";
		}
		else
		{
			return ">5";
		}
	}
}
