package com.mli.springmongointegration.service.Impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mli.springmongointegration.domain.DocumentDetails;
import com.mli.springmongointegration.domain.RequestData;
import com.mli.springmongointegration.repository.DocumentDetailsRepository;
import com.mli.springmongointegration.repository.MliPolicyRepository;
import com.mli.springmongointegration.service.MliPolicyService;

@Service
public class MliPolicyServiceImpl implements MliPolicyService{
    
	@Autowired
    MliPolicyRepository mliPolicyRepository; 
    
    @Autowired
    NextSequenceService nextSequenceService;
	
    @Autowired
    DocumentDetailsRepository documentRepository;
    
	@Override
	public RequestData createOrUpdate(RequestData requestData) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter =DateTimeFormatter.ofPattern("dd-MM-YYYY HH:mm:ss");
 		requestData.setTicketId(String.valueOf(nextSequenceService.getNextSequence("customSequences")));
 		List<DocumentDetails> documentDetailsList = requestData.getDocuments();
		requestData.setDocuments(null);
		requestData.setCaseStatus("SAVE");
		requestData.setCaseSystemReceivedDateTime(formatter.format(LocalDateTime.now()));
		RequestData savedData = mliPolicyRepository.save(requestData);
		Map<String,DocumentDetails> docMap =documentDetailsList.parallelStream().collect(Collectors.toMap(DocumentDetails::getDocumentId,x->x));
		if(!documentDetailsList.isEmpty() && documentDetailsList != null) {
			try {
				documentDetailsList.stream().forEach(doc->{
					//doc.setPolicyDetailId(savedData.getId());
					String docFile=doc.getDocumentFile();
					doc.setDocumentByteStream(Base64.getDecoder().decode(docFile));
					doc.setDocumentStatus("SAVE");
					doc.setDocSystemReceivedDateTime(formatter.format(LocalDateTime.now()));
					doc.setDocumentFile(null);
					String documentObjectId=createOrUpdateDocuments(doc);
					savedData.getDocumentIds().add(documentObjectId);
					docMap.remove(doc.getDocumentId(), doc);
				});
			}catch(Exception e) {
				e.printStackTrace();
			}finally{
				mliPolicyRepository.save(savedData);
			}
		}
		if(documentDetailsList.size() != savedData.getDocumentIds().size()) {
			System.out.println(documentDetailsList.size() - savedData.getDocumentIds().size() +" document is not uploaded");
		}
		System.out.println("NOT UPLOADED" +docMap);
		return savedData;
	}
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public String createOrUpdateDocuments(DocumentDetails documentDetails){
		documentDetails = documentRepository.save(documentDetails);
		System.out.println(documentDetails);
	    return documentDetails.getId();	
	}

}
