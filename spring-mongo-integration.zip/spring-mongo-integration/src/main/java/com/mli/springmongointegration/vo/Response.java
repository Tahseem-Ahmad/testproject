package com.mli.springmongointegration.vo;

public class Response {
 private Header header;
 private MessageInfo msgInfo;
 private Payload payload;
public Header getHeader() {
	return header;
}
public void setHeader(Header header) {
	this.header = header;
}
public MessageInfo getMsgInfo() {
	return msgInfo;
}
public void setMsgInfo(MessageInfo msgInfo) {
	this.msgInfo = msgInfo;
}
public Payload getPayload() {
	return payload;
}
public void setPayload(Payload payload) {
	this.payload = payload;
}
 
 
}
