package com.mli.springmongointegration.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.ProposalNumber;
import com.mli.springmongointegration.repository.ProposalNumberRepository;
import com.mli.springmongointegration.service.ProposalNumberService;

@Service
public class ProposalNumberServiceImpl implements ProposalNumberService{

	@Autowired 
	ProposalNumberRepository proposalNumberRepository;
	
	@Override
	public String createProposalNubers() {
		//proposalNumberRepository.deleteAll();
		Long proposalNumber=100000000L;
		for(int i=0;i<500;i++) {
			ProposalNumber proposalNumber1 =new ProposalNumber();
			proposalNumber1.setPrintStatus("Not Used");
			proposalNumber1.setProposalNumber(proposalNumber+i);
			proposalNumberRepository.save(proposalNumber1);
		}
		return null;
	}

	@Override
	public String getProposalNumber() {
		ProposalNumber proposalNumber = proposalNumberRepository.findFirstProposalNumberOrderByAndPrintStatus("Not Used");
		proposalNumber.setPrintStatus("Y");
		proposalNumberRepository.save(proposalNumber);
		return proposalNumber.getProposalNumber().toString();
	}

}
