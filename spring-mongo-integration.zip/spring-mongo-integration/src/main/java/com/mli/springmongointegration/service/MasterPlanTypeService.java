package com.mli.springmongointegration.service;

import java.util.List;

import com.mli.springmongointegration.domain.MasterPlanType;

public interface MasterPlanTypeService {
  public  List<MasterPlanType> createOrupdateMasterData( List<MasterPlanType> masterPlanTypes);
}
