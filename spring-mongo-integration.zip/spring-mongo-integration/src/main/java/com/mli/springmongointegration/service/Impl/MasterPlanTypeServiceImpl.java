package com.mli.springmongointegration.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.MasterPlanType;
import com.mli.springmongointegration.repository.MasterPlanTypeRepository;
import com.mli.springmongointegration.service.MasterPlanTypeService;

@Service
public class MasterPlanTypeServiceImpl implements MasterPlanTypeService{

	@Autowired
	MasterPlanTypeRepository masterPlanTypeRepository;
	
	@Override
	public List<MasterPlanType> createOrupdateMasterData(List<MasterPlanType> masterPlanTypeList) {
		return masterPlanTypeRepository.save(masterPlanTypeList);
		
	}

}
