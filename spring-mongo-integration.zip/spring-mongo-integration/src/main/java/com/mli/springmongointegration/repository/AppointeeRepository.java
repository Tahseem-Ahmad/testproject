package com.mli.springmongointegration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.Appointee;

public interface AppointeeRepository extends MongoRepository<Appointee, String>{

}
