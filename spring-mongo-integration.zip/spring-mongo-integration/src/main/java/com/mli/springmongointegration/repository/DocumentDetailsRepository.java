package com.mli.springmongointegration.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.DocumentDetails;

public interface DocumentDetailsRepository extends MongoRepository<DocumentDetails, String>{
  Optional<DocumentDetails> findById(String objectId);
}
