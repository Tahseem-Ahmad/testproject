package com.mli.springmongointegration.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class FromFundDetails {
	private String fromFundName;
	private String fromAmount;
	private String fromAmountPercentage;
	public String getFromFundName() {
		return fromFundName;
	}
	public void setFromFundName(String fromFundName) {
		this.fromFundName = fromFundName;
	}
	public String getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(String fromAmount) {
		this.fromAmount = fromAmount;
	}
	public String getFromAmountPercentage() {
		return fromAmountPercentage;
	}
	public void setFromAmountPercentage(String fromAmountPercentage) {
		this.fromAmountPercentage = fromAmountPercentage;
	}
	@Override
	public String toString() {
		return "FromFundDetails [fromFundName=" + fromFundName + ", fromAmount=" + fromAmount
				+ ", fromAmountPercentage=" + fromAmountPercentage + "]";
	}
	
	
}
