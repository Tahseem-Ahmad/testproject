package com.mli.springmongointegration.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mli.springmongointegration.domain.CustomerDetails;
import com.mli.springmongointegration.service.CustomerDetailsService;
import com.mli.springmongointegration.service.ProposalNumberService;

@RestController
public class CustomerDetailsController {
   
Logger logger =Logger.getLogger(CustomerDetailsController.class);
   @Autowired
   CustomerDetailsService customerDetailsService;
	
   @Autowired
   ProposalNumberService proposalNumberService;
   
   @PostMapping("/create")
   public CustomerDetails createOrUpdate(@RequestBody CustomerDetails customerDetails) {
	   return customerDetailsService.createOrUpdate(customerDetails);
   }
   
//   @PostMapping("genearteProposalNumber")
//   public String createProposalNumber() {
//	   proposalNumberService.createProposalNubers();
//	   return "OK";
//   }
   
   @GetMapping("getproposalnumber")
   public String getProposalNumber() {
	   return proposalNumberService.getProposalNumber();
   }
   @GetMapping("getcustomerdetails")
   public CustomerDetails getCustomerDetails(@RequestParam(required=true) String dob, @RequestParam(required=false) String policyNumber,@RequestParam(required=false) String mobileNumber) {
	   logger.info("DOB"+ dob +"PolicyNumber" +policyNumber +"MobileNumber"+mobileNumber);
	   if(policyNumber == null || policyNumber.equalsIgnoreCase("")) {
		   policyNumber="";
	   }
	   if(mobileNumber == null || mobileNumber.equalsIgnoreCase("")) {
		   mobileNumber="";
	   }
	   return customerDetailsService.getCustomerDetails(dob, policyNumber, mobileNumber);
   }
}
