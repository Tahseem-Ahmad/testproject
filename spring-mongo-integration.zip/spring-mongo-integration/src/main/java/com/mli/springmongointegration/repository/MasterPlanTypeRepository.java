package com.mli.springmongointegration.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.MasterPlanType;

public interface MasterPlanTypeRepository extends MongoRepository<MasterPlanType, String>{
	public List<MasterPlanType> findByGenderAndAgeAndSmokerAndIncome(String gender,String age,String smoker,String income);
	public List<MasterPlanType> findByGenderAndAge(String gender,String age);
	public List<MasterPlanType> findByGenderAndAgeAndSmoker(String gender,String age,String smoker);
	

}
