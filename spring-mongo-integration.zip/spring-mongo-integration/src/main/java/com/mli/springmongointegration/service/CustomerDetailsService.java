package com.mli.springmongointegration.service;

import com.mli.springmongointegration.domain.CustomerDetails;

public interface CustomerDetailsService {

	public CustomerDetails createOrUpdate(CustomerDetails customerDetails);
}
