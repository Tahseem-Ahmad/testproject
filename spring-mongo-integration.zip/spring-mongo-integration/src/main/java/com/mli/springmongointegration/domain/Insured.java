package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="INSURED_DETAILS")
public class Insured {
	
	 @Id
	 private String id;	
	 private String name;
	 private String status;
	 private String relationship;
	 private String dob;
	 private String percentageShare;
	 private String address;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPercentageShare() {
		return percentageShare;
	}
	public void setPercentageShare(String percentageShare) {
		this.percentageShare = percentageShare;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Insured [id=" + id + ", name=" + name + ", status=" + status + ", relationship=" + relationship
				+ ", dob=" + dob + ", percentageShare=" + percentageShare + ", address=" + address + "]";
	}
	 
}
