package com.mli.springmongointegration.vo;

public class Header {
   private String soaMsgVersion;
   private String soaCorrelationId;
   private String soaAppId;
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	@Override
	public String toString() {
		return "Header [soaMsgVersion=" + soaMsgVersion + ", soaCorrelationId=" + soaCorrelationId + ", soaAppId="
				+ soaAppId + "]";
	}
   
   
}
