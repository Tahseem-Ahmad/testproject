package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
@Document(collection = "NOMINEE_DETAILS")
public class Nominee {

 @Id
 private String id;	
 private String nomineeName;
 private String nomineeStatus;
 private String nomineeRelationship;
 private String nomineeDob;
 private String percentageShare;
 private String address;
 
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getNomineeName() {
	return nomineeName;
}
public void setNomineeName(String nomineeName) {
	this.nomineeName = nomineeName;
}
public String getNomineeRelationship() {
	return nomineeRelationship;
}

public String getNomineeStatus() {
	return nomineeStatus;
}
public void setNomineeStatus(String nomineeStatus) {
	this.nomineeStatus = nomineeStatus;
}
public void setNomineeRelationship(String nomineeRelationship) {
	this.nomineeRelationship = nomineeRelationship;
}
public String getNomineeDob() {
	return nomineeDob;
}
public void setNomineeDob(String nomineeDob) {
	this.nomineeDob = nomineeDob;
}
public String getPercentageShare() {
	return percentageShare;
}
public void setPercentageShare(String percentageShare) {
	this.percentageShare = percentageShare;
}

public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Nominee [nomineeName=" + nomineeName + ", nomineeStatus=" + nomineeStatus + ", nomineeRelationship="
			+ nomineeRelationship + ", nomineeDob=" + nomineeDob + ", percentageShare=" + percentageShare + ", address="
			+ address + "]";
}


 
}
