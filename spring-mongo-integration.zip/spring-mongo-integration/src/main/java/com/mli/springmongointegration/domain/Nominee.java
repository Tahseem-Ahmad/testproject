package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
@Document(collection = "NOMINEE_DETAILS")
public class Nominee {

	@Id
	private String id;	
	private String nomineeName;
	private String nomineeStatus;
	private String nomineeRelationship;
	private String nomineeDob;
	private String percentageShare;
	private String address;
	private String mobileNumber;
	private String clientId;
	private String gender;
	private String smoker;
	private String planName;
	private String policyTerm;
	private String premiumPolicyTerm;
	private String premium;
	private String sumAssured;
	private String paymentMode;
	
	private String policyNumber;

	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPremiumPolicyTerm() {
		return premiumPolicyTerm;
	}
	public void setPremiumPolicyTerm(String premiumPolicyTerm) {
		this.premiumPolicyTerm = premiumPolicyTerm;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getSmoker() {
		return smoker;
	}
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
	public String getNomineeRelationship() {
		return nomineeRelationship;
	}

	public String getNomineeStatus() {
		return nomineeStatus;
	}
	public void setNomineeStatus(String nomineeStatus) {
		this.nomineeStatus = nomineeStatus;
	}
	public void setNomineeRelationship(String nomineeRelationship) {
		this.nomineeRelationship = nomineeRelationship;
	}
	public String getNomineeDob() {
		return nomineeDob;
	}
	public void setNomineeDob(String nomineeDob) {
		this.nomineeDob = nomineeDob;
	}
	public String getPercentageShare() {
		return percentageShare;
	}
	public void setPercentageShare(String percentageShare) {
		this.percentageShare = percentageShare;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Nominee [nomineeName=" + nomineeName + ", nomineeStatus=" + nomineeStatus + ", nomineeRelationship="
				+ nomineeRelationship + ", nomineeDob=" + nomineeDob + ", percentageShare=" + percentageShare + ", address="
				+ address + "]";
	}



}
