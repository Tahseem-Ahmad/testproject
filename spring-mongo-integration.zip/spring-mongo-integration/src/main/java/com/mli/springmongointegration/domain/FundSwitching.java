package com.mli.springmongointegration.domain;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class FundSwitching {
 private List<FromFundDetails> fromFundDetails;
 private List<ToFundDetails> toFundDetails;
public List<FromFundDetails> getFromFundDetails() {
	return fromFundDetails;
}
public void setFromFundDetails(List<FromFundDetails> fromFundDetails) {
	this.fromFundDetails = fromFundDetails;
}
public List<ToFundDetails> getToFundDetails() {
	return toFundDetails;
}
public void setToFundDetails(List<ToFundDetails> toFundDetails) {
	this.toFundDetails = toFundDetails;
}
@Override
public String toString() {
	return "FundSwitching [fromFundDetails=" + fromFundDetails + ", toFundDetails=" + toFundDetails + "]";
}
 


 
 
}
