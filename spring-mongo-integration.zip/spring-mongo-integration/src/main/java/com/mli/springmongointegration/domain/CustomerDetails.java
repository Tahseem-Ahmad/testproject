package com.mli.springmongointegration.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CUSTOMER_DETAILS")
public class CustomerDetails {
	   @Id
	   private String id;
	   private String clientId;
	   private String policyNumber;
	   private String dob;
	   private String firstName;
	   private String middleName;
	   private String lastName;
	   private String email;
	   private String planName;
	   private String address;
	   private String panNumber;
	   private String mobileNumber;
	   private String gender;
	   List<Nominee> nominees;
	   List<Insured> insureds;
	   List<Appointee> appointees;
	   List<Trustee> trustees;
	   
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public List<Nominee> getNominees() {
		return nominees;
	}
	public void setNominees(List<Nominee> nominees) {
		this.nominees = nominees;
	}
	public List<Insured> getInsureds() {
		return insureds;
	}
	public void setInsureds(List<Insured> insureds) {
		this.insureds = insureds;
	}
	public List<Appointee> getAppointees() {
		return appointees;
	}
	public void setAppointees(List<Appointee> appointees) {
		this.appointees = appointees;
	}
	public List<Trustee> getTrustees() {
		return trustees;
	}
	public void setTrustees(List<Trustee> trustees) {
		this.trustees = trustees;
	}
	@Override
	public String toString() {
		return "CustomerDetails [id=" + id + ", clientId=" + clientId + ", policyNumber=" + policyNumber + ", dob="
				+ dob + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", email=" + email + ", planName=" + planName + ", address=" + address + ", panNumber=" + panNumber
				+ ", mobileNumber=" + mobileNumber + ", gender=" + gender + ", nominees=" + nominees + ", insureds="
				+ insureds + ", appointees=" + appointees + ", trustees=" + trustees + "]";
	}
	
}
