package com.mli.springmongointegration.domain;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "CUSTOMER_DETAILS")
public class CustomerDetails {
	@Id
	private String id;
	private String clientId;
	private String policyNumber;
	private String dob;
	private String firstName;
	private String middleName;
	private String lastName;
	private String email;
	private String planName;
	private String address;
	private String panNumber;
	private String mobileNumber;
	private String gender;
	private String smoker;
	private String income;
	List<Nominee> nominees;
	List<Insured> insureds;
	List<Appointee> appointees;
	List<Trustee> trustees;
	List<Owner> owner;
	
	private String policyTerm;
	private String premiumPolicyTerm;
	private String premium;
	private String sumAssured;
	private String paymentMode;
	
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPremiumPolicyTerm() {
		return premiumPolicyTerm;
	}
	public void setPremiumPolicyTerm(String premiumPolicyTerm) {
		this.premiumPolicyTerm = premiumPolicyTerm;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getSmoker() {
		return smoker;
	}
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public List<Nominee> getNominees() {
		return nominees;
	}
	public void setNominees(List<Nominee> nominees) {
		this.nominees = nominees;
	}
	public List<Insured> getInsureds() {
		return insureds;
	}
	public void setInsureds(List<Insured> insureds) {
		this.insureds = insureds;
	}
	public List<Appointee> getAppointees() {
		return appointees;
	}
	public void setAppointees(List<Appointee> appointees) {
		this.appointees = appointees;
	}
	public List<Trustee> getTrustees() {
		return trustees;
	}
	public void setTrustees(List<Trustee> trustees) {
		this.trustees = trustees;
	}
	public List<Owner> getOwner() {
		return owner;
	}
	public void setOwner(List<Owner> owner) {
		this.owner = owner;
	}
	@Override
	public String toString() {
		return "CustomerDetails [id=" + id + ", clientId=" + clientId + ", policyNumber=" + policyNumber + ", dob="
				+ dob + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName
				+ ", email=" + email + ", planName=" + planName + ", address=" + address + ", panNumber=" + panNumber
				+ ", mobileNumber=" + mobileNumber + ", gender=" + gender + ", smoker=" + smoker + ", income=" + income
				+ ", nominees=" + nominees + ", insureds=" + insureds + ", appointees=" + appointees + ", trustees="
				+ trustees + ", owner=" + owner + "]";
	}
}
