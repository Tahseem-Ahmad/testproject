package com.mli.springmongointegration.service;

public interface ProposalNumberService {

	public String createProposalNubers();
	public String getProposalNumber();
}
