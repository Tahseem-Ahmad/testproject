package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Document(collection="PLAN_MASTER")
@JsonIgnoreProperties(ignoreUnknown=true)
public class MasterPlanType {
	@Id
	private String id;	
	private String planName;
	private String income;
	private String age;
	private String gender;
	private String smoker;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getIncome() {
		return income;
	}
	public void setIncome(String income) {
		this.income = income;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSmoker() {
		return smoker;
	}
	public void setSmoker(String smoker) {
		this.smoker = smoker;
	}
	@Override
	public String toString() {
		return "MasterPlanType [id=" + id + ", planName=" + planName + ", income=" + income + ", age=" + age
				+ ", gender=" + gender + ", smoker=" + smoker + "]";
	}
}
