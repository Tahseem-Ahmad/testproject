package com.mli.springmongointegration.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.RequestData;

public interface MliPolicyRepository extends MongoRepository<RequestData, String>{
  
	Optional<RequestData> findByTicketId(String ticketId);
  
}
