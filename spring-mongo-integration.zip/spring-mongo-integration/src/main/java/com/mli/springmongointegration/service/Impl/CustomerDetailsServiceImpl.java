package com.mli.springmongointegration.service.Impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.CustomerDetails;
import com.mli.springmongointegration.repository.CustomerDetailsRepository;
import com.mli.springmongointegration.service.CustomerDetailsService;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

	Logger logger =Logger.getLogger(CustomerDetailsServiceImpl.class);
	@Autowired
	CustomerDetailsRepository customerDetailsRepository;
	
	@Override
	public CustomerDetails createOrUpdate(CustomerDetails customerDetails) {
		logger.info(customerDetails);
		//customerDetailsRepository.deleteAll();
		return customerDetailsRepository.save(customerDetails);
	}

	@Override
	public CustomerDetails getCustomerDetails(String dob, String policyNumber, String mobileNumber) {
		CustomerDetails customerDetails=new CustomerDetails();
		
        if(policyNumber != null && !policyNumber.equalsIgnoreCase("")) {
        	     logger.info("DOB" + dob +"PolicyNumber" + policyNumber);
        		 customerDetails = customerDetailsRepository.findByDobAndPolicyNumber(dob, policyNumber);
        		 logger.info("CustomerDetails" + customerDetails);
        }
        if(mobileNumber != null && !mobileNumber.equalsIgnoreCase("")) {
        		logger.info("DOB" + dob +"MobileNumber" + mobileNumber);
    			customerDetails = customerDetailsRepository.findByDobAndMobileNumber(dob, mobileNumber);
    			logger.info("CustomerDetails" + customerDetails);
        }
		return customerDetails;
	}

}
