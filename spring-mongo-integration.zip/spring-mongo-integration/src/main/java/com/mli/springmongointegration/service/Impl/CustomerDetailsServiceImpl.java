package com.mli.springmongointegration.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.CustomerDetails;
import com.mli.springmongointegration.repository.CustomerDetailsRepository;
import com.mli.springmongointegration.service.CustomerDetailsService;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

	@Autowired
	CustomerDetailsRepository customerDetailsRepository;
	
	@Override
	public CustomerDetails createOrUpdate(CustomerDetails customerDetails) {
		return customerDetailsRepository.save(customerDetails);
	}

}
