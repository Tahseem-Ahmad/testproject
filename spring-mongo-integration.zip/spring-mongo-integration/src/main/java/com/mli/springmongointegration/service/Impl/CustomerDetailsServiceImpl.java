package com.mli.springmongointegration.service.Impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.Appointee;
import com.mli.springmongointegration.domain.CustomerDetails;
import com.mli.springmongointegration.domain.Insured;
import com.mli.springmongointegration.domain.Nominee;
import com.mli.springmongointegration.domain.Trustee;
import com.mli.springmongointegration.repository.CustomerDetailsRepository;
import com.mli.springmongointegration.service.CustomerDetailsService;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

	Logger logger =Logger.getLogger(CustomerDetailsServiceImpl.class);
	@Autowired
	CustomerDetailsRepository customerDetailsRepository;
	
	@Override
	public CustomerDetails createOrUpdate(CustomerDetails customerDetails) {
		logger.info(customerDetails);
		//customerDetailsRepository.deleteAll();
		return customerDetailsRepository.save(customerDetails);
	}

	@Override
	public CustomerDetails getCustomerDetails(String dob, String policyNumber, String mobileNumber)
	{
		CustomerDetails customerDetails=new CustomerDetails();
		
        if(policyNumber != null && !policyNumber.equalsIgnoreCase("")) 
        {
        	     logger.info("DOB" + dob +"PolicyNumber" + policyNumber);
        		 customerDetails = customerDetailsRepository.findByDobAndPolicyNumber(dob, policyNumber);
        		 logger.info("CustomerDetails" + customerDetails);
        }
        if(mobileNumber != null && !mobileNumber.equalsIgnoreCase("")) 
        {
        		logger.info("DOB" + dob +"MobileNumber" + mobileNumber);
    			customerDetails = customerDetailsRepository.findByDobAndMobileNumber(dob, mobileNumber);
    			logger.info("CustomerDetails" + customerDetails);
        }
        if(!customerDetails.getClientId().isEmpty())
        {
        	if(!customerDetails.getNominees().isEmpty())
        	{
        		//Nominee
        		for(int i=0 ; i<customerDetails.getNominees().size(); i++)
        		{
        			Nominee nominee = customerDetails.getNominees().get(i);
        			if(!nominee.getClientId().isEmpty() 
        					&& !nominee.getNomineeRelationship().isEmpty() 
        					&& !nominee.getNomineeName().isEmpty())
        			{
        				//it's Ok
        			}
        			else
        			{
        				customerDetails.getNominees().remove(i);
        			}
        		}
        		
        		//insureds
        		for(int i=0 ; i<customerDetails.getInsureds().size(); i++)
        		{
        			Insured insured = customerDetails.getInsureds().get(i);
        			if(!insured.getClientId().isEmpty() 
        					&& !insured.getRelationship().isEmpty() 
        					&& !insured.getName().isEmpty()
        					&& !insured.getClientId().equalsIgnoreCase(customerDetails.getClientId()))
        			{
        				//it's Ok
        			}
        			else
        			{
        				customerDetails.getInsureds().remove(i);
        			}
        		}
        		
        		//Appointee
        		for(int i=0 ; i<customerDetails.getAppointees().size(); i++)
        		{
        			Appointee appointee = customerDetails.getAppointees().get(i);
        			if(!appointee.getClientId().isEmpty() 
        					&& !appointee.getRelationship().isEmpty() 
        					&& !appointee.getName().isEmpty())
        			{
        				//it's Ok
        			}
        			else
        			{
        				customerDetails.getAppointees().remove(i);
        			}
        		}
        		
        		//Trustee
        		for(int i=0 ; i<customerDetails.getTrustees().size(); i++)
        		{
        			Trustee Trustee = customerDetails.getTrustees().get(i);
        			if(!Trustee.getClientId().isEmpty() 
        					&& !Trustee.getRelationship().isEmpty() 
        					&& !Trustee.getName().isEmpty())
        			{
        				//it's Ok
        			}
        			else
        			{
        				customerDetails.getTrustees().remove(i);
        			}
        		}
        	}
        }
		return customerDetails;
	}

}
