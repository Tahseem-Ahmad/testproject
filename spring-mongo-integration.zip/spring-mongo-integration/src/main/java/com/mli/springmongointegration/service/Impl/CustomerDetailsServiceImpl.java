package com.mli.springmongointegration.service.Impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.springmongointegration.domain.Appointee;
import com.mli.springmongointegration.domain.CustomerDetails;
import com.mli.springmongointegration.domain.Insured;
import com.mli.springmongointegration.domain.Nominee;
import com.mli.springmongointegration.domain.Owner;
import com.mli.springmongointegration.domain.Trustee;
import com.mli.springmongointegration.repository.CustomerDetailsRepository;
import com.mli.springmongointegration.repository.MasterPlanTypeRepository;
import com.mli.springmongointegration.service.CustomerDetailsService;

@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

	Logger logger =Logger.getLogger(CustomerDetailsServiceImpl.class);
	@Autowired
	CustomerDetailsRepository customerDetailsRepository;

	@Autowired
	MasterPlanTypeRepository masterPlanTypeRepository;

	
	final static String age1 = "0-30";
	final static String age2 = "30-45";
	final static String age3 = "45-60";
	final static String income1 = "<5";
	final static String income2 = ">5";

	@Override
	public CustomerDetails createOrUpdate(CustomerDetails customerDetails) {
		logger.info(customerDetails);
		//customerDetailsRepository.deleteAll();
		return customerDetailsRepository.save(customerDetails);
	}

	@Override
	public CustomerDetails getCustomerDetails(String dob, String policyNumber, String mobileNumber)
	{
		CustomerDetails customerDetails=new CustomerDetails();

		if(policyNumber != null && !policyNumber.equalsIgnoreCase("")) 
		{
			logger.info("DOB" + dob +"PolicyNumber" + policyNumber);
			customerDetails = customerDetailsRepository.findByDobAndPolicyNumber(dob, policyNumber);
			logger.info("CustomerDetails" + customerDetails);
		}
		if(mobileNumber != null && !mobileNumber.equalsIgnoreCase("")) 
		{
			logger.info("DOB" + dob +"MobileNumber" + mobileNumber);
			customerDetails = customerDetailsRepository.findByDobAndMobileNumber(dob, mobileNumber);
			logger.info("CustomerDetails" + customerDetails);
		}

		if(!customerDetails.getClientId().isEmpty())
		{
			List<Owner> ownerList = new ArrayList<>();
			Owner owner = new Owner();
			owner.setAddress(customerDetails.getAddress());
			owner.setClientId(customerDetails.getClientId());
			owner.setDob(customerDetails.getDob());
			owner.setEmail(customerDetails.getFirstName());
			owner.setFirstName(customerDetails.getFirstName());
			owner.setGender(customerDetails.getGender());
			owner.setId(customerDetails.getId());
			owner.setIncome(customerDetails.getIncome());
			owner.setLastName(customerDetails.getLastName());
			owner.setMiddleName(customerDetails.getMiddleName());
			owner.setMobileNumber(customerDetails.getMobileNumber());
			owner.setPanNumber(customerDetails.getPanNumber());
			owner.setPlanName(customerDetails.getPlanName());
			owner.setPolicyNumber(customerDetails.getPolicyNumber());
			owner.setSmoker(customerDetails.getSmoker());
			//Here blank data is setted it is logic 
			customerDetails.setOwner(ownerList);
			
			if(!customerDetails.getNominees().isEmpty())
			{
				//Owner
				for(int i=0 ; i<customerDetails.getNominees().size(); i++)
				{
					Nominee nominee = customerDetails.getNominees().get(i);
					if(!nominee.getClientId().isEmpty() 
							&& !nominee.getNomineeRelationship().isEmpty() 
							&& !nominee.getNomineeName().isEmpty())
					{
						//it's Ok
						if(!nominee.getGender().isEmpty())
						{
							if(nominee.getGender().equalsIgnoreCase("F"))
							{
								//check is he is a insured if yes then show plan as per existing plan else
								//send Cancer
								nominee.setPlanName("CANCER");
							}
							else
							{
								//check is he is a insured if yes then show plan as per existing plan else
								String age = this.ageCalculator(nominee.getNomineeDob());
								if(age.equalsIgnoreCase(age1))
								{
									nominee.setPlanName("OSP");
								}
								else if(age.equalsIgnoreCase(age2))
								{
									if(this.incomeCalculator(customerDetails.getIncome()).equalsIgnoreCase(income1))
									{
										nominee.setPlanName("OSP");
									}
									else
									{
										nominee.setPlanName("OTP");
									}
								}
								else if(age.equalsIgnoreCase(age3))
								{
									nominee.setPlanName("OSP");
								}
							}
						}

//						List<MasterPlanType> masterPlanType = masterPlanTypeRepository.findByGenderAndAgeAndSmokerAndIncome(
//								nominee.getGender().trim(),
//								this.ageCalculator(nominee.getNomineeDob()),
//								nominee.getSmoker().isEmpty()?"N":nominee.getSmoker(),
//										this.incomeCalculator(customerDetails.getIncome()));
//						if(!masterPlanType.isEmpty())
//						{
//
//						}
					}
					else
					{
						customerDetails.getNominees().remove(i);
					}
				}
				
				//Nominee
				for(int i=0 ; i<customerDetails.getNominees().size(); i++)
				{
					Nominee nominee = customerDetails.getNominees().get(i);
					if(!nominee.getClientId().isEmpty() 
							&& !nominee.getNomineeRelationship().isEmpty() 
							&& !nominee.getNomineeName().isEmpty())
					{
						//it's Ok
						if(!nominee.getGender().isEmpty())
						{
							if(nominee.getGender().equalsIgnoreCase("F"))
							{
								//check is he is a insured if yes then show plan as per existing plan else
								//send Cancer
								nominee.setPlanName("CANCER");
							}
							else
							{
								//check is he is a insured if yes then show plan as per existing plan else
								String age = this.ageCalculator(nominee.getNomineeDob());
								if(age.equalsIgnoreCase(age1))
								{
									nominee.setPlanName("OSP");
								}
								else if(age.equalsIgnoreCase(age2))
								{
									if(this.incomeCalculator(customerDetails.getIncome()).equalsIgnoreCase(income1))
									{
										nominee.setPlanName("OSP");
									}
									else
									{
										nominee.setPlanName("OTP");
									}
								}
								else if(age.equalsIgnoreCase(age3))
								{
									nominee.setPlanName("OSP");
								}
							}
						}

//						List<MasterPlanType> masterPlanType = masterPlanTypeRepository.findByGenderAndAgeAndSmokerAndIncome(
//								nominee.getGender().trim(),
//								this.ageCalculator(nominee.getNomineeDob()),
//								nominee.getSmoker().isEmpty()?"N":nominee.getSmoker(),
//										this.incomeCalculator(customerDetails.getIncome()));
//						if(!masterPlanType.isEmpty())
//						{
//
//						}
					}
					else
					{
						customerDetails.getNominees().remove(i);
					}
				}

				//insureds
				for(int i=0 ; i<customerDetails.getInsureds().size(); i++)
				{
					Insured insured = customerDetails.getInsureds().get(i);
					if(!insured.getClientId().isEmpty() 
							&& !insured.getRelationship().isEmpty() 
							&& !insured.getName().isEmpty()
							&& !insured.getClientId().equalsIgnoreCase(customerDetails.getClientId()))
					{
						//it's Ok
						customerDetails.getInsureds().remove(i);
						
						
						if(!owner.getGender().isEmpty())
						{
							if(owner.getGender().equalsIgnoreCase("F"))
							{
								//check is he is a insured if yes then show plan as per existing plan else
								//send Cancer
								owner.setPlanName("CANCER");
							}
							else
							{
								//check is he is a insured if yes then show plan as per existing plan else
								String age = this.ageCalculator(owner.getDob());
								if(age.equalsIgnoreCase(age1))
								{
									owner.setPlanName("OSP");
								}
								else if(age.equalsIgnoreCase(age2))
								{
									if(this.incomeCalculator(customerDetails.getIncome()).equalsIgnoreCase(income1))
									{
										owner.setPlanName("OSP");
									}
									else
									{
										owner.setPlanName("OTP");
									}
								}
								else if(age.equalsIgnoreCase(age3))
								{
									owner.setPlanName("OSP");
								}
							}
						}
						ownerList.add(owner);
						customerDetails.setOwner(ownerList);
						
					}
					else
					{
						customerDetails.getInsureds().remove(i);
					}
				}

				//Appointee
				for(int i=0 ; i<customerDetails.getAppointees().size(); i++)
				{
					Appointee appointee = customerDetails.getAppointees().get(i);
					if(!appointee.getClientId().isEmpty() 
							&& !appointee.getRelationship().isEmpty() 
							&& !appointee.getName().isEmpty())
					{
						//it's Ok
						if(!appointee.getGender().isEmpty())
						{
							if(appointee.getGender().equalsIgnoreCase("F"))
							{
								//check is he is a insured if yes then show plan as per existing plan else
								//send Cancer
								appointee.setPlanName("CANCER");
							}
							else
							{
								//check is he is a insured if yes then show plan as per existing plan else
								String age = this.ageCalculator(appointee.getDob());
								if(age.equalsIgnoreCase(age1))
								{
									appointee.setPlanName("OSP");
								}
								else if(age.equalsIgnoreCase(age2))
								{
									if(this.incomeCalculator(customerDetails.getIncome()).equalsIgnoreCase(income1))
									{
										appointee.setPlanName("OSP");
									}
									else
									{
										appointee.setPlanName("OTP");
									}
								}
								else if(age.equalsIgnoreCase(age3))
								{
									appointee.setPlanName("OSP");
								}
							}
						}
					}
					else
					{
						customerDetails.getAppointees().remove(i);
					}
				}

				//Trustee
				for(int i=0 ; i<customerDetails.getTrustees().size(); i++)
				{
					Trustee trustee = customerDetails.getTrustees().get(i);
					if(!trustee.getClientId().isEmpty() 
							&& !trustee.getRelationship().isEmpty() 
							&& !trustee.getName().isEmpty())
					{
						//it's Ok
						if(!trustee.getGender().isEmpty())
						{
							if(trustee.getGender().equalsIgnoreCase("F"))
							{
								//check is he is a insured if yes then show plan as per existing plan else
								//send Cancer
								trustee.setPlanName("CANCER");
							}
							else
							{
								//check is he is a insured if yes then show plan as per existing plan else
								String age = this.ageCalculator(trustee.getDob());
								if(age.equalsIgnoreCase(age1))
								{
									trustee.setPlanName("OSP");
								}
								else if(age.equalsIgnoreCase(age2))
								{
									if(this.incomeCalculator(customerDetails.getIncome()).equalsIgnoreCase(income1))
									{
										trustee.setPlanName("OSP");
									}
									else
									{
										trustee.setPlanName("OTP");
									}
								}
								else if(age.equalsIgnoreCase(age3))
								{
									trustee.setPlanName("OSP");
								}
							}
						}
					}
					else
					{
						customerDetails.getTrustees().remove(i);
					}
				}
			}
		}
		return customerDetails;
	}

	public String ageCalculator(String dob) 
	{
		int ageCalculated = 0;
		SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("dd-mm-yyyy");
		try 
		{
			Date dateOfBirth = dateTimeFormatter.parse(dob);
			LocalDate birthDateTime = dateOfBirth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

			Period p = Period.between(birthDateTime, LocalDate.now());
			ageCalculated=p.getYears();
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		if(ageCalculated<=30)
		{
			return age1;
		}
		else if(ageCalculated<=45) 
		{
			return age2;
		}
		else if(ageCalculated<=60) 
		{
			return age3;
		}
		return "NA";
	}

	private static String incomeCalculator(String income)
	{

		Integer incomeData = Integer.parseInt(income.isEmpty()?"0":income);
		if(incomeData<=500000)
		{
			return income1;
		}
		else
		{
			return income2;
		}
	}
}
