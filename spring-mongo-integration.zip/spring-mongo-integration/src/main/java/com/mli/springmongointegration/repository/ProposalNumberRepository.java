package com.mli.springmongointegration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.ProposalNumber;



public interface ProposalNumberRepository extends MongoRepository<ProposalNumber, String>{
  public ProposalNumber findFirstProposalNumberOrderByAndPrintStatus(String printStatus);
}
