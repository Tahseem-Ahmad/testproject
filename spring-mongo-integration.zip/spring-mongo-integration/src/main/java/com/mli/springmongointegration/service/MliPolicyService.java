package com.mli.springmongointegration.service;

import com.mli.springmongointegration.domain.DocumentDetails;
import com.mli.springmongointegration.domain.RequestData;

public interface MliPolicyService {
 public RequestData createOrUpdate(RequestData requestData);

 public String createOrUpdateDocuments(DocumentDetails documentDetails);
}
