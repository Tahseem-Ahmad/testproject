package com.mli.springmongointegration.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
@Document(collection="MLI_POLICY_DATA")
public class RequestData {
	   
       @Id
	   private String id;
	   private List<DocumentDetails> documents =new ArrayList<>();
	   private String panCardNumber;
	   private String panCardSubmitted;
	   private String accountHolderName;
	   private String bankAccountNumber;
	   private String bankAccountType;
	   private String micrCode;
	   private String ifscCode;
	   private String bankNameAndBranchName;
	   private String refundMethod;
	   private String ownerClientAccount;
	   private String preferredMailingAddress;
	   private String currentAddNo;
	   private String currentAddRoad;
	   private String  currentAddLandmark;
	   private String  currentAddCity;
	   private String  currentAddState;
	   private String  currentAddPincode;
	   private String  permanentAddNo;
	   private String  permanentAddRoad;
	   private String  permanentAddLandmark;
	   private String  permanentAddCity;
	   private String  permanentAddState;
	   private String  permanentAddPincode;
	   private String  workAddNo;
	   private String  workAddRoad;
	   private String  workAddLandmark;
	   private String  workAddCity;
	   private String  workAddState;
	   private String  workAddPincode;
	   private String  bonusOptionSelected;
	   private String  deactivationOfFundAllocation;
	   private String  deactivationOfSTP;
	   private String  nfoOptionSelected;
	   private String  premiumModeSelected;
	   private String companyName;
	   private List<Nominee> nominees =new ArrayList<>();
	   private String apointeeName;
	   private String apointeeRelationship;
	   private String apointeeDob;
	   private FundSwitching fundSwitchings;
	   private String newMobileNumber;
	   private String newEmailId;
	   private String newName;
	   private String aadharReferenceKey;
	   private String  policyno;
	   private String  workTypeName;
	   private String  caseIntroductionDateTime;
	   private String  caseEmissionDateTime;
	   private String  goReceivedTime;
	   private String  goReceivedDate;
	   private String  retryCount;
	   private String  caseStatus;
	   private String  comment;
	   private String  ticketId;
	   private String  customerLetterDate;
	   private String  hoReceivedDate;
	   private String  sourceApplication;
	   private String  agentCode;
	   private String  requestorType;
	   private String  ssoId;
	   private String  requestedDateTime;
	   private String  policyHolderName;
	   private String  clientIdPolicyOwner;
	   private String clientIdCustomer;
	   private List<String> documentIds =new ArrayList<>();
	   private String caseId;
	   private String caseSystemReceivedDateTime;
	   
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getCaseSystemReceivedDateTime() {
		return caseSystemReceivedDateTime;
	}
	public void setCaseSystemReceivedDateTime(String caseSystemReceivedDateTime) {
		this.caseSystemReceivedDateTime = caseSystemReceivedDateTime;
	}
	public String getClientIdCustomer() {
		return clientIdCustomer;
	}
	public void setClientIdCustomer(String clientIdCustomer) {
		this.clientIdCustomer = clientIdCustomer;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getDocumentIds() {
		return documentIds;
	}
	public void setDocumentIds(List<String> documentIds) {
		this.documentIds = documentIds;
	}
	public List<DocumentDetails> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentDetails> documents) {
		this.documents = documents;
	}
	public String getPanCardNumber() {
		return panCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}
	public String getPanCardSubmitted() {
		return panCardSubmitted;
	}
	public void setPanCardSubmitted(String panCardSubmitted) {
		this.panCardSubmitted = panCardSubmitted;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public String getBankAccountType() {
		return bankAccountType;
	}
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankNameAndBranchName() {
		return bankNameAndBranchName;
	}
	public void setBankNameAndBranchName(String bankNameAndBranchName) {
		this.bankNameAndBranchName = bankNameAndBranchName;
	}
	public String getRefundMethod() {
		return refundMethod;
	}
	public void setRefundMethod(String refundMethod) {
		this.refundMethod = refundMethod;
	}
	public String getOwnerClientAccount() {
		return ownerClientAccount;
	}
	public void setOwnerClientAccount(String ownerClientAccount) {
		this.ownerClientAccount = ownerClientAccount;
	}
	public String getPreferredMailingAddress() {
		return preferredMailingAddress;
	}
	public void setPreferredMailingAddress(String preferredMailingAddress) {
		this.preferredMailingAddress = preferredMailingAddress;
	}
	public String getCurrentAddNo() {
		return currentAddNo;
	}
	public void setCurrentAddNo(String currentAddNo) {
		this.currentAddNo = currentAddNo;
	}
	public String getCurrentAddRoad() {
		return currentAddRoad;
	}
	public void setCurrentAddRoad(String currentAddRoad) {
		this.currentAddRoad = currentAddRoad;
	}
	public String getCurrentAddLandmark() {
		return currentAddLandmark;
	}
	public void setCurrentAddLandmark(String currentAddLandmark) {
		this.currentAddLandmark = currentAddLandmark;
	}
	public String getCurrentAddCity() {
		return currentAddCity;
	}
	public void setCurrentAddCity(String currentAddCity) {
		this.currentAddCity = currentAddCity;
	}
	public String getCurrentAddState() {
		return currentAddState;
	}
	public void setCurrentAddState(String currentAddState) {
		this.currentAddState = currentAddState;
	}
	public String getCurrentAddPincode() {
		return currentAddPincode;
	}
	public void setCurrentAddPincode(String currentAddPincode) {
		this.currentAddPincode = currentAddPincode;
	}
	public String getPermanentAddNo() {
		return permanentAddNo;
	}
	public void setPermanentAddNo(String permanentAddNo) {
		this.permanentAddNo = permanentAddNo;
	}
	public String getPermanentAddRoad() {
		return permanentAddRoad;
	}
	public void setPermanentAddRoad(String permanentAddRoad) {
		this.permanentAddRoad = permanentAddRoad;
	}
	public String getPermanentAddLandmark() {
		return permanentAddLandmark;
	}
	public void setPermanentAddLandmark(String permanentAddLandmark) {
		this.permanentAddLandmark = permanentAddLandmark;
	}
	public String getPermanentAddCity() {
		return permanentAddCity;
	}
	public void setPermanentAddCity(String permanentAddCity) {
		this.permanentAddCity = permanentAddCity;
	}
	public String getPermanentAddState() {
		return permanentAddState;
	}
	public void setPermanentAddState(String permanentAddState) {
		this.permanentAddState = permanentAddState;
	}
	public String getPermanentAddPincode() {
		return permanentAddPincode;
	}
	public void setPermanentAddPincode(String permanentAddPincode) {
		this.permanentAddPincode = permanentAddPincode;
	}
	public String getWorkAddNo() {
		return workAddNo;
	}
	public void setWorkAddNo(String workAddNo) {
		this.workAddNo = workAddNo;
	}
	public String getWorkAddRoad() {
		return workAddRoad;
	}
	public void setWorkAddRoad(String workAddRoad) {
		this.workAddRoad = workAddRoad;
	}
	public String getWorkAddLandmark() {
		return workAddLandmark;
	}
	public void setWorkAddLandmark(String workAddLandmark) {
		this.workAddLandmark = workAddLandmark;
	}
	public String getWorkAddCity() {
		return workAddCity;
	}
	public void setWorkAddCity(String workAddCity) {
		this.workAddCity = workAddCity;
	}
	public String getWorkAddState() {
		return workAddState;
	}
	public void setWorkAddState(String workAddState) {
		this.workAddState = workAddState;
	}
	public String getWorkAddPincode() {
		return workAddPincode;
	}
	public void setWorkAddPincode(String workAddPincode) {
		this.workAddPincode = workAddPincode;
	}
	public String getBonusOptionSelected() {
		return bonusOptionSelected;
	}
	public void setBonusOptionSelected(String bonusOptionSelected) {
		this.bonusOptionSelected = bonusOptionSelected;
	}

	
	public String getDeactivationOfFundAllocation() {
		return deactivationOfFundAllocation;
	}
	public void setDeactivationOfFundAllocation(String deactivationOfFundAllocation) {
		this.deactivationOfFundAllocation = deactivationOfFundAllocation;
	}
	public String getDeactivationOfSTP() {
		return deactivationOfSTP;
	}
	public void setDeactivationOfSTP(String deactivationOfSTP) {
		this.deactivationOfSTP = deactivationOfSTP;
	}
	public String getNfoOptionSelected() {
		return nfoOptionSelected;
	}
	public void setNfoOptionSelected(String nfoOptionSelected) {
		this.nfoOptionSelected = nfoOptionSelected;
	}
	public String getPremiumModeSelected() {
		return premiumModeSelected;
	}
	public void setPremiumModeSelected(String premiumModeSelected) {
		this.premiumModeSelected = premiumModeSelected;
	}
	public List<Nominee> getNominees() {
		return nominees;
	}
	public void setNominees(List<Nominee> nominees) {
		this.nominees = nominees;
	}
	public String getApointeeName() {
		return apointeeName;
	}
	public void setApointeeName(String apointeeName) {
		this.apointeeName = apointeeName;
	}
	public String getApointeeRelationship() {
		return apointeeRelationship;
	}
	public void setApointeeRelationship(String apointeeRelationship) {
		this.apointeeRelationship = apointeeRelationship;
	}
	public String getApointeeDob() {
		return apointeeDob;
	}
	public void setApointeeDob(String apointeeDob) {
		this.apointeeDob = apointeeDob;
	}
	public FundSwitching getFundSwitchings() {
		return fundSwitchings;
	}
	public void setFundSwitchings(FundSwitching fundSwitchings) {
		this.fundSwitchings = fundSwitchings;
	}
	public String getNewMobileNumber() {
		return newMobileNumber;
	}
	public void setNewMobileNumber(String newMobileNumber) {
		this.newMobileNumber = newMobileNumber;
	}
	public String getNewEmailId() {
		return newEmailId;
	}
	public void setNewEmailId(String newEmailId) {
		this.newEmailId = newEmailId;
	}
	public String getNewName() {
		return newName;
	}
	public void setNewName(String newName) {
		this.newName = newName;
	}
	public String getAadharReferenceKey() {
		return aadharReferenceKey;
	}
	public void setAadharReferenceKey(String aadharReferenceKey) {
		this.aadharReferenceKey = aadharReferenceKey;
	}
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	public String getWorkTypeName() {
		return workTypeName;
	}
	public void setWorkTypeName(String workTypeName) {
		this.workTypeName = workTypeName;
	}
	public String getCaseIntroductionDateTime() {
		return caseIntroductionDateTime;
	}
	public void setCaseIntroductionDateTime(String caseIntroductionDateTime) {
		this.caseIntroductionDateTime = caseIntroductionDateTime;
	}
	public String getCaseEmissionDateTime() {
		return caseEmissionDateTime;
	}
	public void setCaseEmissionDateTime(String caseEmissionDateTime) {
		this.caseEmissionDateTime = caseEmissionDateTime;
	}
	public String getGoReceivedTime() {
		return goReceivedTime;
	}
	public void setGoReceivedTime(String goReceivedTime) {
		this.goReceivedTime = goReceivedTime;
	}
	public String getGoReceivedDate() {
		return goReceivedDate;
	}
	public void setGoReceivedDate(String goReceivedDate) {
		this.goReceivedDate = goReceivedDate;
	}
	
	public String getRetryCount() {
		return retryCount;
	}
	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getTicketId() {
		return ticketId;
	}
	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}
	public String getCustomerLetterDate() {
		return customerLetterDate;
	}
	public void setCustomerLetterDate(String customerLetterDate) {
		this.customerLetterDate = customerLetterDate;
	}
	public String getHoReceivedDate() {
		return hoReceivedDate;
	}
	public void setHoReceivedDate(String hoReceivedDate) {
		this.hoReceivedDate = hoReceivedDate;
	}
	public String getSourceApplication() {
		return sourceApplication;
	}
	public void setSourceApplication(String sourceApplication) {
		this.sourceApplication = sourceApplication;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getRequestorType() {
		return requestorType;
	}
	public void setRequestorType(String requestorType) {
		this.requestorType = requestorType;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getRequestedDateTime() {
		return requestedDateTime;
	}
	public void setRequestedDateTime(String requestedDateTime) {
		this.requestedDateTime = requestedDateTime;
	}
	public String getPolicyHolderName() {
		return policyHolderName;
	}
	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}
	public String getClientIdPolicyOwner() {
		return clientIdPolicyOwner;
	}
	public void setClientIdPolicyOwner(String clientIdPolicyOwner) {
		this.clientIdPolicyOwner = clientIdPolicyOwner;
	}
	@Override
	public String toString() {
		return "RequestData [id=" + id + ", documents=" + documents + ", panCardNumber=" + panCardNumber
				+ ", panCardSubmitted=" + panCardSubmitted + ", accountHolderName=" + accountHolderName
				+ ", bankAccountNumber=" + bankAccountNumber + ", bankAccountType=" + bankAccountType + ", micrCode="
				+ micrCode + ", ifscCode=" + ifscCode + ", bankNameAndBranchName=" + bankNameAndBranchName
				+ ", refundMethod=" + refundMethod + ", ownerClientAccount=" + ownerClientAccount
				+ ", preferredMailingAddress=" + preferredMailingAddress + ", currentAddNo=" + currentAddNo
				+ ", currentAddRoad=" + currentAddRoad + ", currentAddLandmark=" + currentAddLandmark
				+ ", currentAddCity=" + currentAddCity + ", currentAddState=" + currentAddState + ", currentAddPincode="
				+ currentAddPincode + ", permanentAddNo=" + permanentAddNo + ", permanentAddRoad=" + permanentAddRoad
				+ ", permanentAddLandmark=" + permanentAddLandmark + ", permanentAddCity=" + permanentAddCity
				+ ", permanentAddState=" + permanentAddState + ", permanentAddPincode=" + permanentAddPincode
				+ ", workAddNo=" + workAddNo + ", workAddRoad=" + workAddRoad + ", workAddLandmark=" + workAddLandmark
				+ ", workAddCity=" + workAddCity + ", workAddState=" + workAddState + ", workAddPincode="
				+ workAddPincode + ", bonusOptionSelected=" + bonusOptionSelected + ", deactivationOfFundAllocation="
				+ deactivationOfFundAllocation + ", deactivationOfSTP=" + deactivationOfSTP + ", nfoOptionSelected="
				+ nfoOptionSelected + ", premiumModeSelected=" + premiumModeSelected + ", nominees=" + nominees
				+ ", fundSwitchings=" + fundSwitchings + ", newMobileNumber=" + newMobileNumber + ", newEmailId="
				+ newEmailId + ", newName=" + newName + ", aadharReferenceKey=" + aadharReferenceKey + ", policyno="
				+ policyno + ", workTypeName=" + workTypeName + ", caseIntroductionDateTime=" + caseIntroductionDateTime
				+ ", caseEmissionDateTime=" + caseEmissionDateTime + ", goReceivedTime=" + goReceivedTime + ", goReceivedDate="
				+ goReceivedDate + ", retryCount=" + retryCount + ", caseStatus=" + caseStatus + ", comment=" + comment
				+ ", ticketId=" + ticketId + ", customerLetterDate=" + customerLetterDate + ", hoReceivedDate="
				+ hoReceivedDate + ", sourceApplication=" + sourceApplication + ", agentCode=" + agentCode
				+ ", requestorType=" + requestorType + ", ssoId=" + ssoId + ", requestedDateTime=" + requestedDateTime
				+ ", policyHolderName=" + policyHolderName + ", clientIdPolicyOwner=" + clientIdPolicyOwner
				+ ", documentIds=" + documentIds + "]";
	}
	   
	   
	   
}
