package com.mli.springmongointegration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.CustomerDetails;

public interface CustomerDetailsRepository extends MongoRepository<CustomerDetails, String>{
	
	public CustomerDetails findByDobAndPolicyNumber(String dob,String policyNumber);
	public CustomerDetails findByDobAndMobileNumber(String dob,String mobileNumber);

}
