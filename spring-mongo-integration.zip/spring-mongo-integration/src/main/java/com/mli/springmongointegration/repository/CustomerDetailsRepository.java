package com.mli.springmongointegration.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.mli.springmongointegration.domain.CustomerDetails;

public interface CustomerDetailsRepository extends MongoRepository<CustomerDetails, String>{

}
