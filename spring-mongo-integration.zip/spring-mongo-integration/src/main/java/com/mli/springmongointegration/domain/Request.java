package com.mli.springmongointegration.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mli.springmongointegration.domain.RequestData;
import com.mli.springmongointegration.vo.Header;

@JsonIgnoreProperties(ignoreUnknown=true)
public class Request {
  private Header header;
  private RequestData requestData;
public Header getHeader() {
	return header;
}
public void setHeader(Header header) {
	this.header = header;
}
public RequestData getRequestData() {
	return requestData;
}
public void setRequestData(RequestData requestData) {
	this.requestData = requestData;
}
@Override
public String toString() {
	return "Request [header=" + header + ", requestData=" + requestData + "]";
}
  
}
