package com.mli.springmongointegration.domain;

import java.util.List;

public class MasterPlanTypes 
{
	List<MasterPlanType> masterPlanType;

	public List<MasterPlanType> getMasterPlanType() {
		return masterPlanType;
	}

	public void setMasterPlanType(List<MasterPlanType> masterPlanType) {
		this.masterPlanType = masterPlanType;
	}

	@Override
	public String toString() {
		return "MasterPlanTypes [masterPlanType=" + masterPlanType + "]";
	}
}
