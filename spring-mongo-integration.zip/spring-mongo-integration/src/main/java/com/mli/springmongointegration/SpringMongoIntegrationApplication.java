package com.mli.springmongointegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMongoIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMongoIntegrationApplication.class, args);
	}
}
