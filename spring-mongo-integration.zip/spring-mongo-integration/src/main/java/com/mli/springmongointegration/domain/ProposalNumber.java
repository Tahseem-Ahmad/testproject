package com.mli.springmongointegration.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="PROPOSAL_NUMBER")
public class ProposalNumber {
	
	@Id
	private String id;
	private Long proposalNumber;
	private String printStatus;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public Long getProposalNumber() {
		return proposalNumber;
	}
	public void setProposalNumber(Long proposalNumber) {
		this.proposalNumber = proposalNumber;
	}
	public String getPrintStatus() {
		return printStatus;
	}
	public void setPrintStatus(String printStatus) {
		this.printStatus = printStatus;
	}
	@Override
	public String toString() {
		return "ProposalNumer [id=" + id + ", proposalNumber=" + proposalNumber + ", printStatus=" + printStatus + "]";
	}
	
	
}
