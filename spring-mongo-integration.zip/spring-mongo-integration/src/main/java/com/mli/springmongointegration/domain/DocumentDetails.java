package com.mli.springmongointegration.domain;

import java.util.Arrays;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
@Document(collection="DOCUMENT_DETAILS")
public class DocumentDetails {
	  @Id
	  private String id;
	  private String documentFile;
	  private byte[] documentByteStream;
      private String documentName;
      private String documentType;
      private String documentUploadDateTime;
      private String documentId;
	  private String documentEmissionDateTime;
      private String documentStatus;
      private String retryCount;
      private String comment;
      private String policyDetailId;
      private String docSystemReceivedDateTime;
      
      public String getDocSystemReceivedDateTime() {
		return docSystemReceivedDateTime;
	}
	public void setDocSystemReceivedDateTime(String docSystemReceivedDateTime) {
		this.docSystemReceivedDateTime = docSystemReceivedDateTime;
	}
	public String getId() {
  		return id;
  	}
  	public void setId(String id) {
  		this.id = id;
  	}
  	
    public String getDocumentFile() {
		return documentFile;
	}
	public void setDocumentFile(String documentFile) {
		this.documentFile = documentFile;
	}
	public byte[] getDocumentByteStream() {
		return documentByteStream;
	}
    
	public void setDocumentByteStream(byte[] documentByteStream) {
		this.documentByteStream = documentByteStream;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentUploadDateTime() {
		return documentUploadDateTime;
	}
	public void setDocumentUploadDateTime(String documentUploadDateTime) {
		this.documentUploadDateTime = documentUploadDateTime;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getDocumentEmissionDateTime() {
		return documentEmissionDateTime;
	}
	public void setDocumentEmissionDateTime(String documentEmissionDateTime) {
		this.documentEmissionDateTime = documentEmissionDateTime;
	}
	public String getDocumentStatus() {
		return documentStatus;
	}
	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}
	public String getRetryCount() {
		return retryCount;
	}
	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public String getPolicyDetailId() {
		return policyDetailId;
	}
	public void setPolicyDetailId(String policyDetailId) {
		this.policyDetailId = policyDetailId;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((documentName == null) ? 0 : documentName.hashCode());
		result = prime * result + ((documentType == null) ? 0 : documentType.hashCode());
		result = prime * result + ((policyDetailId == null) ? 0 : policyDetailId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DocumentDetails other = (DocumentDetails) obj;
		if (documentName == null) {
			if (other.documentName != null)
				return false;
		} else if (!documentName.equals(other.documentName))
			return false;
		if (documentType == null) {
			if (other.documentType != null)
				return false;
		} else if (!documentType.equals(other.documentType))
			return false;
		if (policyDetailId == null) {
			if (other.policyDetailId != null)
				return false;
		} else if (!policyDetailId.equals(other.policyDetailId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DocumentDetails [id=" + id + ", documentByteStream=" + Arrays.toString(documentByteStream)
				+ ", documentName=" + documentName + ", documentType=" + documentType + ", documentUploadDateTime="
				+ documentUploadDateTime + ", documentId=" + documentId + ", documentEmissionDateTime="
				+ documentEmissionDateTime + ", documentStatus=" + documentStatus + ", retryCount=" + retryCount
				+ ", comment=" + comment + ", policyDetailId=" + policyDetailId + "]";
	}
      
	
}
